package com.example

import com.example.data.TelebirrDao
import com.example.data.TelebirrRepository
import com.example.data.TransactionEntity
import com.example.data.RecipientEntity
import com.example.data.WalletStateEntity
import com.example.util.ReceiptDownloadHelper
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  private class FakeTelebirrDao : TelebirrDao {
    private val wallet = MutableStateFlow<WalletStateEntity?>(null)
    private val recipients = MutableStateFlow<List<RecipientEntity>>(emptyList())
    private val transactions = MutableStateFlow<List<TransactionEntity>>(emptyList())

    override fun observeWalletState(): Flow<WalletStateEntity?> = wallet
    override suspend fun getWalletState(): WalletStateEntity? = wallet.value
    override suspend fun upsertWalletState(state: WalletStateEntity) { wallet.value = state }
    override fun observeRecentRecipients(): Flow<List<RecipientEntity>> = recipients
    override suspend fun upsertRecipient(recipient: RecipientEntity) {
      recipients.value = listOf(recipient) + recipients.value.filter { it.phoneNumber != recipient.phoneNumber }
    }
    override suspend fun insertRecipients(recipients: List<RecipientEntity>) {
      this.recipients.value = recipients
    }
    override suspend fun clearAllRecipients() { recipients.value = emptyList() }
    override fun observeTransactions(): Flow<List<TransactionEntity>> = transactions
    override suspend fun getTransactionCount(): Int = transactions.value.size
    override suspend fun insertTransaction(transaction: TransactionEntity) {
      transactions.value = listOf(transaction) + transactions.value
    }
    override suspend fun insertTransactions(transactions: List<TransactionEntity>) {
      this.transactions.value = transactions
    }
    override suspend fun deleteTransactionByNumber(transactionNumber: String) {
      transactions.value = transactions.value.filter { it.transactionNumber != transactionNumber }
    }
  }

  @Test
  fun sendMoney_persistsRecipientName_and_calculatesFeeCorrectly() = runBlocking {
    val repo = TelebirrRepository(FakeTelebirrDao())
    repo.ensureSeeded()

    val result =
      repo.sendMoney(
        recipientName = "Solomon",
        recipientPhone = "942528916",
        amount = 5.00,
        notes = "Test transfer",
      )

    assertTrue(result.isSuccess)
    val tx = result.getOrThrow()
    assertEquals("Solomon", tx.recipientName)
    assertEquals("251942528916", tx.recipientPhone)
    assertEquals(1.00, tx.serviceFee, 0.01)
    assertEquals(6.00, tx.totalAmount, 0.01)

    val updatedWallet = repositoryBalanceCheck(repo)
    assertEquals(999_994.00, updatedWallet, 0.01)
  }

  private suspend fun repositoryBalanceCheck(repo: TelebirrRepository): Double =
    repo.walletState.first()!!.balance

  @Test
  fun normalizePhone_and_maskPhone_matchTelebirrFormat() {
    assertEquals("251942528916", TelebirrRepository.normalizeEthiopianPhone("0942528916"))
    assertEquals("2519****8916", TelebirrRepository.maskPhone("251942528916"))
  }

  @Test
  fun receiptDownloadHelper_formatsFileNameAndShareText() {
    assertEquals(
      "telebirr_receipt_DKM0IAV1BY.png",
      ReceiptDownloadHelper.buildReceiptFileName("DKM0IAV1BY"),
    )
    assertEquals(
      "telebirr_receipt_TX_123_45.png",
      ReceiptDownloadHelper.buildReceiptFileName("TX/123 45"),
    )

    val tx =
      TransactionEntity(
        transactionNumber = "DKM0IAV1BY",
        recipientName = "Solomon",
        recipientPhone = "251942528916",
        amount = 5.00,
        serviceFee = 1.00,
        totalAmount = 6.00,
        transactionType = "Transfer Money",
        formattedTime = "2026/11/22 11:14:41",
        notes = "Lunch",
        timestampMillis = 1L,
      )
    val shareText = ReceiptDownloadHelper.buildReceiptShareText(tx)
    assertTrue(shareText.contains("Amount: -6.00 (ETB)"))
    assertTrue(shareText.contains("Transaction To: Solomon"))
    assertTrue(shareText.contains("Recipient Number: 251942528916"))
    assertTrue(shareText.contains("Transaction Number: DKM0IAV1BY"))
    assertTrue(shareText.contains("Notes: Lunch"))
  }
}
