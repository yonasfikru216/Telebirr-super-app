package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "wallet_state")
data class WalletStateEntity(
  @PrimaryKey val id: Int = 1,
  val userName: String = "fikiru",
  val phoneNumber: String = "961041860",
  val balance: Double = 1_000_000.00,
  val endekise: Double = 2271.17,
  val reward: Double = 0.00,
  val level: String = "Level 3",
  val language: String = "English",
  val isLoggedIn: Boolean = false,
)

@Entity(tableName = "recipients")
data class RecipientEntity(
  @PrimaryKey val phoneNumber: String,
  val name: String,
  val avatarKey: String = "default",
  val lastUsedMillis: Long = System.currentTimeMillis(),
)

@Entity(tableName = "transactions")
data class TransactionEntity(
  @PrimaryKey val transactionNumber: String,
  val recipientName: String,
  val recipientPhone: String,
  val amount: Double,
  val serviceFee: Double,
  val totalAmount: Double,
  val notes: String = "",
  val transactionType: String = "Transfer Money",
  val formattedTime: String,
  val timestampMillis: Long = System.currentTimeMillis(),
)

data class PaymentCategory(
  val id: String,
  val title: String,
  val services: List<PaymentServiceItem>,
)

data class PaymentServiceItem(
  val id: String,
  val title: String,
  val iconKey: String,
  val categoryTitle: String,
)

data class MiniAppItem(
  val id: String,
  val title: String,
  val iconKey: String,
  val description: String,
  val category: String,
)

data class SmsNotificationItem(
  val id: String,
  val title: String,
  val body: String,
  val timeLabel: String,
  val isUnread: Boolean = true,
)
