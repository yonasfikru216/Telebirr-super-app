package com.example.data

object TelebirrCatalog {
  val languages = listOf("English", "አማርኛ (Amharic)", "Afaan Oromoo", "ትግርኛ (Tigrigna)")

  val paymentCategories: List<PaymentCategory> =
    listOf(
      PaymentCategory(
        id = "utility",
        title = "Utility",
        services =
          listOf(
            PaymentServiceItem("ethio_bill", "Pay Ethio\ntelecom Bill", "ethio", "Utility"),
            PaymentServiceItem("electric_util", "Electric Utility", "eeu", "Utility"),
            PaymentServiceItem(
              "aawsa",
              "Addis Ababa\nWater utility",
              "aawsa",
              "Utility",
            ),
            PaymentServiceItem("derash", "Water Utility\nby Derash", "derash", "Utility"),
            PaymentServiceItem("webirr", "Water Utility\nby WeBirr", "webirr", "Utility"),
            PaymentServiceItem("wm_general", "W M GENERAL\nTRADING PLC", "wm", "Utility"),
            PaymentServiceItem("unicash", "Water utility\nby UniCash", "unicash", "Utility"),
            PaymentServiceItem("eeu_post", "Ethiopian\nElectric Utility", "eeu_alt", "Utility"),
            PaymentServiceItem("websprix_util", "WebSprix", "websprix", "Utility"),
            PaymentServiceItem("palaba", "Water utility\nby palaba", "palaba", "Utility"),
          ),
      ),
      PaymentCategory(
        id = "tax_gov",
        title = "Tax and Goverment Service",
        services =
          listOf(
            PaymentServiceItem("mor", "Ministry of\nRevenue Tax", "gov", "Tax and Goverment Service"),
            PaymentServiceItem("passport", "Immigration &\nPassport Fee", "gov", "Tax and Goverment Service"),
            PaymentServiceItem("customs", "Ethiopian\nCustoms", "gov", "Tax and Goverment Service"),
            PaymentServiceItem("trade_reg", "Trade License\nRenewal", "gov", "Tax and Goverment Service"),
          ),
      ),
      PaymentCategory(
        id = "mesob",
        title = "MESOB One-stop Service Center",
        services =
          listOf(
            PaymentServiceItem("mesob_id", "City Resident\nService", "mesob", "MESOB One-stop Service Center"),
            PaymentServiceItem("mesob_land", "Land & Housing\nService", "mesob", "MESOB One-stop Service Center"),
          ),
      ),
      PaymentCategory(
        id = "transport",
        title = "Transport Service",
        services =
          listOf(
            PaymentServiceItem("edr_pay", "Ethio-Djibouti\nRailway", "train", "Transport Service"),
            PaymentServiceItem("anbessa", "City Bus\nPass", "bus", "Transport Service"),
            PaymentServiceItem("ride_pay", "RIDE Driver\nWallet", "ride", "Transport Service"),
            PaymentServiceItem("toll_road", "Expressway\nToll Gate", "toll", "Transport Service"),
          ),
      ),
      PaymentCategory(
        id = "entertainment",
        title = "Entertainment Service",
        services =
          listOf(
            PaymentServiceItem("dstv_pay", "DStv\nSubscription", "dstv", "Entertainment Service"),
            PaymentServiceItem("canal_plus", "CANAL+\nEthiopia", "tv", "Entertainment Service"),
            PaymentServiceItem("cinema", "Cinema &\nTheater", "cinema", "Entertainment Service"),
          ),
      ),
      PaymentCategory(
        id = "ecommerce",
        title = "E-commerce",
        services =
          listOf(
            PaymentServiceItem("zemen_ecom", "Zemen\nGEBEYA", "zemen", "E-commerce"),
            PaymentServiceItem("zmall_ecom", "Zmall\nDelivery", "zmall", "E-commerce"),
            PaymentServiceItem("ashewa_ecom", "Ashewa\nMarketplace", "ashewa", "E-commerce"),
          ),
      ),
      PaymentCategory(
        id = "events",
        title = "Event and Ticketing",
        services =
          listOf(
            PaymentServiceItem("ger_tick", "Great Ethiopian\nRun", "ger", "Event and Ticketing"),
            PaymentServiceItem("concert_tick", "Addis Events &\nConcerts", "ticket", "Event and Ticketing"),
          ),
      ),
      PaymentCategory(
        id = "education",
        title = "Education fee",
        services =
          listOf(
            PaymentServiceItem("aau_fee", "Addis Ababa\nUniversity", "edu", "Education fee"),
            PaymentServiceItem("school_pay", "School\nTuition Fee", "edu", "Education fee"),
          ),
      ),
      PaymentCategory(
        id = "fundraising",
        title = "Fundraising",
        services =
          listOf(
            PaymentServiceItem("gerd_fund", "Abay Dam\nSupport", "fund", "Fundraising"),
            PaymentServiceItem("red_cross", "Ethiopian\nRed Cross", "fund", "Fundraising"),
          ),
      ),
      PaymentCategory(
        id = "traffic_penalty",
        title = "Traffic Penalty",
        services =
          listOf(
            PaymentServiceItem("addis_traffic", "Addis Traffic\nPenalty", "traffic", "Traffic Penalty"),
            PaymentServiceItem("federal_traffic", "Federal Road\nFine", "traffic", "Traffic Penalty"),
          ),
      ),
      PaymentCategory(
        id = "insurance",
        title = "Insurance",
        services =
          listOf(
            PaymentServiceItem("eic", "Ethiopian\nInsurance Corp", "insurance", "Insurance"),
            PaymentServiceItem("awash_ins", "Awash\nInsurance", "insurance", "Insurance"),
          ),
      ),
      PaymentCategory(
        id = "non_gov",
        title = "Non Government Service",
        services =
          listOf(
            PaymentServiceItem("chamber", "Chamber of\nCommerce", "ngo", "Non Government Service"),
            PaymentServiceItem("assoc", "Professional\nAssociations", "ngo", "Non Government Service"),
          ),
      ),
      PaymentCategory(
        id = "agriculture",
        title = "Agriculture & Livestock",
        services =
          listOf(
            PaymentServiceItem("agri_input", "Fertilizer &\nSeed Supply", "agri", "Agriculture & Livestock"),
            PaymentServiceItem("livestock", "Livestock\nMarket", "agri", "Agriculture & Livestock"),
          ),
      ),
      PaymentCategory(
        id = "medical",
        title = "Medical and Health Services",
        services =
          listOf(
            PaymentServiceItem("cbhi", "Community\nHealth Insurance", "health", "Medical and Health Services"),
            PaymentServiceItem("hospital", "Hospital &\nClinic Bill", "health", "Medical and Health Services"),
          ),
      ),
    )

  val miniApps: List<MiniAppItem> =
    listOf(
      MiniAppItem("my_ethiotel", "My Ethiotel", "ethio", "Manage mobile data, voice bundles, and ethio telecom plans.", "Telecom"),
      MiniAppItem("telebirr_remit", "telebirrRemit", "remit", "Receive international remittances directly into your wallet.", "Finance"),
      MiniAppItem("tele_online", "tele-Online Fixed\nService", "tele_online", "Order and manage broadband & fixed-line services.", "Telecom"),
      MiniAppItem("ethiopian_air", "Ethiopian Airlines", "airlines", "Search flights, book tickets, and pay seamlessly with telebirr.", "Travel"),
      MiniAppItem("fayda_id", "NID (Fayda) Digital\nID", "fayda", "Link and verify your Fayda National Digital ID.", "Government"),
      MiniAppItem("esl", "Ethiopian Shipping\nand Logistics", "esl", "Track shipments and pay logistics fees.", "Logistics"),
      MiniAppItem("teninete", "Teninete", "teninete", "Access healthcare directory and pharmacy services.", "Health"),
      MiniAppItem("fayda_print", "NID (Fayda)\nprinting", "fayda_print", "Request physical printing of your Fayda ID card.", "Government"),
      MiniAppItem("mydstv", "MyDStv", "dstv", "Renew DStv packages and clear decoder errors instantly.", "Entertainment"),
      MiniAppItem("howlow", "HOWLOW", "howlow", "Digital marketplace and retail deals.", "Shopping"),
      MiniAppItem("sitota", "SITOTA", "sitota", "Send digital gifts, flowers, and vouchers to loved ones.", "Lifestyle"),
      MiniAppItem("eservices", "E-Services", "eservices", "Ethiopian federal public e-services portal.", "Government"),
      MiniAppItem("ger", "Great Ethiopian\nRun", "ger", "Register and pay for Great Ethiopian Run events.", "Sports"),
      MiniAppItem("medhin_link", "Medhin Link", "medhin", "Digital health insurance verification and claims.", "Health"),
      MiniAppItem("ride", "RIDE", "ride", "Book rides across Addis Ababa and pay with telebirr.", "Transport"),
      MiniAppItem("public_transport", "Public Transport", "public_transport", "Digital ticketing for city bus & transit routes.", "Transport"),
      MiniAppItem("hulu_beje", "Hulu beje", "hulu_beje", "Buy bus, cinema, and event tickets in one place.", "Ticketing"),
      MiniAppItem("websprix", "WebSprix", "websprix", "Pay monthly WebSprix fiber internet bills.", "Internet"),
      MiniAppItem("zmall", "Zmall", "zmall", "Order food, groceries, and pharmacy deliveries.", "Delivery"),
      MiniAppItem("digital_equb", "Digital Equb", "equb", "Create and join trusted digital Equb saving circles.", "Savings"),
      MiniAppItem("ashewa", "Ashewa", "ashewa", "Shop electronics, fashion, and home essentials online.", "Shopping"),
      MiniAppItem("act_american", "ACT American", "act", "Pay tuition and registration fees for ACT American College.", "Education"),
      MiniAppItem("afroread", "AfroRead", "afroread", "Read Ethiopian ebooks, audiobooks, and magazines.", "Education"),
      MiniAppItem("shofer", "SHOFER", "shofer", "On-demand ride-hailing and parcel delivery.", "Transport"),
      MiniAppItem("edr_ticket", "EDR Ticket Booking", "edr", "Book Addis Ababa–Djibouti railway passenger tickets.", "Travel"),
      MiniAppItem("teledrive", "teledrive", "teledrive", "Ethio telecom secure cloud backup and file sharing.", "Cloud"),
      MiniAppItem("zemen_dispatcher", "Zemen GEBEYA\nDispatcher", "zemen_dispatch", "Manage Zemen GEBEYA merchant deliveries.", "Logistics"),
      MiniAppItem("qetero", "Qetero", "qetero", "Book appointments for clinics, salons, and services.", "Booking"),
      MiniAppItem("children_race", "2026 Children’s\nRaces presented\nby BofA", "ger", "Register young runners for the 2026 Children's Races.", "Sports"),
    )
}
