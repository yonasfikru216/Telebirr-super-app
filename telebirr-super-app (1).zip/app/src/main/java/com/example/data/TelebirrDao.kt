package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface TelebirrDao {
  @Query("SELECT * FROM wallet_state WHERE id = 1")
  fun observeWalletState(): Flow<WalletStateEntity?>

  @Query("SELECT * FROM wallet_state WHERE id = 1")
  suspend fun getWalletState(): WalletStateEntity?

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertWalletState(state: WalletStateEntity)

  @Query("SELECT * FROM recipients ORDER BY lastUsedMillis DESC")
  fun observeRecentRecipients(): Flow<List<RecipientEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun upsertRecipient(recipient: RecipientEntity)

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertRecipients(recipients: List<RecipientEntity>)

  @Query("DELETE FROM recipients")
  suspend fun clearAllRecipients()

  @Query("SELECT * FROM transactions ORDER BY timestampMillis DESC")
  fun observeTransactions(): Flow<List<TransactionEntity>>

  @Query("SELECT COUNT(*) FROM transactions")
  suspend fun getTransactionCount(): Int

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertTransaction(transaction: TransactionEntity)

  @Insert(onConflict = OnConflictStrategy.IGNORE)
  suspend fun insertTransactions(transactions: List<TransactionEntity>)

  @Query("DELETE FROM transactions WHERE transactionNumber = :transactionNumber")
  suspend fun deleteTransactionByNumber(transactionNumber: String)
}
