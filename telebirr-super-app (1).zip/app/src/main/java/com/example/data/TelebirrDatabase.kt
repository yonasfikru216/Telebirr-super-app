package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(
  entities = [WalletStateEntity::class, RecipientEntity::class, TransactionEntity::class],
  version = 3,
  exportSchema = false,
)
abstract class TelebirrDatabase : RoomDatabase() {
  abstract fun telebirrDao(): TelebirrDao

  companion object {
    @Volatile private var INSTANCE: TelebirrDatabase? = null

    fun getInstance(context: Context): TelebirrDatabase {
      return INSTANCE
        ?: synchronized(this) {
          val instance =
            Room.databaseBuilder(
                context.applicationContext,
                TelebirrDatabase::class.java,
                "telebirr_superapp.db",
              )
              .fallbackToDestructiveMigration(true)
              .build()
          INSTANCE = instance
          instance
        }
    }
  }
}
