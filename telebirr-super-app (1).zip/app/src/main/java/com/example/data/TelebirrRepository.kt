package com.example.data

import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.random.Random
import kotlinx.coroutines.flow.Flow

class TelebirrRepository(private val dao: TelebirrDao) {
  val walletState: Flow<WalletStateEntity?> = dao.observeWalletState()
  val recentRecipients: Flow<List<RecipientEntity>> = dao.observeRecentRecipients()
  val transactions: Flow<List<TransactionEntity>> = dao.observeTransactions()

  suspend fun ensureSeeded() {
    if (dao.getWalletState() == null) {
      dao.upsertWalletState(
        WalletStateEntity(
          id = 1,
          userName = "fikiru",
          phoneNumber = "961041860",
          balance = 1_000_000.00,
          endekise = 2271.17,
          reward = 0.00,
          level = "Level 3",
          language = "English",
          isLoggedIn = false,
        )
      )
      val baseTime = System.currentTimeMillis()
      dao.insertRecipients(
        listOf(
          RecipientEntity(
            phoneNumber = "251911204411",
            name = "Yohannes",
            avatarKey = "default",
            lastUsedMillis = baseTime - 10_000L,
          ),
          RecipientEntity(
            phoneNumber = "251911482209",
            name = "Birhanu",
            avatarKey = "default",
            lastUsedMillis = baseTime - 20_000L,
          ),
          RecipientEntity(
            phoneNumber = "251912778833",
            name = "Kibebe",
            avatarKey = "default",
            lastUsedMillis = baseTime - 30_000L,
          ),
          RecipientEntity(
            phoneNumber = "251913904521",
            name = "Berihun",
            avatarKey = "default",
            lastUsedMillis = baseTime - 40_000L,
          ),
          RecipientEntity(
            phoneNumber = "251921663418",
            name = "KENE",
            avatarKey = "kene",
            lastUsedMillis = baseTime - 50_000L,
          ),
          RecipientEntity(
            phoneNumber = "251942528916",
            name = "Solomon",
            avatarKey = "solomon",
            lastUsedMillis = baseTime - 60_000L,
          ),
        )
      )
    }
    if (dao.getTransactionCount() == 0) {
      val now = System.currentTimeMillis()
      dao.insertTransactions(
        listOf(
          TransactionEntity(
            transactionNumber = "DKM6IC896I",
            recipientName = "Solomon Fikru",
            recipientPhone = "251942528916",
            amount = 1.00,
            serviceFee = 1.00,
            totalAmount = 2.00,
            notes = "Transfer",
            transactionType = "Transfer Money",
            formattedTime = "2026/11/22 11:42:20",
            timestampMillis = now - 60_000L,
          ),
          TransactionEntity(
            transactionNumber = "DKM0IAV1BY",
            recipientName = "Solomon",
            recipientPhone = "251942528916",
            amount = 5.00,
            serviceFee = 1.00,
            totalAmount = 6.00,
            notes = "",
            transactionType = "Transfer Money",
            formattedTime = "2026/11/22 11:14:41",
            timestampMillis = now - 1_800_000L,
          ),
        )
      )
    }
  }

  suspend fun login(phoneDigits: String) {
    ensureSeeded()
    val current = dao.getWalletState() ?: WalletStateEntity()
    val cleaned = phoneDigits.filter { it.isDigit() }.ifEmpty { "961041860" }
    dao.upsertWalletState(current.copy(phoneNumber = cleaned, isLoggedIn = true))
  }

  suspend fun logout() {
    val current = dao.getWalletState() ?: return
    dao.upsertWalletState(current.copy(isLoggedIn = false))
  }

  suspend fun updateLanguage(language: String) {
    val current = dao.getWalletState() ?: WalletStateEntity()
    dao.upsertWalletState(current.copy(language = language))
  }

  suspend fun clearRecentRecipients() {
    dao.clearAllRecipients()
  }

  suspend fun deleteTransaction(transactionNumber: String) {
    dao.deleteTransactionByNumber(transactionNumber)
  }

  suspend fun cashIn(amount: Double): Result<TransactionEntity> {
    if (amount <= 0.0) return Result.failure(IllegalArgumentException("Enter a valid amount"))
    val current = dao.getWalletState() ?: WalletStateEntity()
    val newBalance = ((current.balance + amount) * 100).toLong() / 100.0
    dao.upsertWalletState(current.copy(balance = newBalance))
    val tx =
      createTransactionRecord(
        recipientName = "Telebirr Agent",
        recipientPhone = current.phoneNumber,
        amount = amount,
        serviceFee = 0.0,
        totalAmount = amount,
        notes = "Wallet Cash In",
        transactionType = "Cash In",
      )
    dao.insertTransaction(tx)
    return Result.success(tx)
  }

  suspend fun sendMoney(
    recipientName: String,
    recipientPhone: String,
    amount: Double,
    notes: String,
    transactionType: String = "Transfer Money",
    avatarKey: String = "default",
  ): Result<TransactionEntity> {
    if (amount <= 0.0) {
      return Result.failure(IllegalArgumentException("Amount must be greater than 0"))
    }
    val current = dao.getWalletState() ?: WalletStateEntity()
    val fee = calculateServiceFee(amount)
    val total = ((amount + fee) * 100).toLong() / 100.0
    if (total > current.balance) {
      return Result.failure(
        IllegalStateException(
          "Insufficient balance. Available: ${String.format(Locale.US, "%.2f", current.balance)} ETB"
        )
      )
    }

    val updatedBalance = ((current.balance - total) * 100).toLong() / 100.0
    val earnedReward = ((current.reward + (amount * 0.01)) * 100).toLong() / 100.0
    dao.upsertWalletState(current.copy(balance = updatedBalance, reward = earnedReward))

    val normalizedPhone = normalizeEthiopianPhone(recipientPhone)
    val finalName = recipientName.trim().ifEmpty { normalizedPhone }
    val resolvedAvatar =
      when {
        avatarKey != "default" -> avatarKey
        finalName.equals("Solomon", ignoreCase = true) -> "solomon"
        finalName.equals("KENE", ignoreCase = true) -> "kene"
        else -> "default"
      }
    dao.upsertRecipient(
      RecipientEntity(
        phoneNumber = normalizedPhone,
        name = finalName,
        avatarKey = resolvedAvatar,
        lastUsedMillis = System.currentTimeMillis(),
      )
    )

    val tx =
      createTransactionRecord(
        recipientName = finalName,
        recipientPhone = normalizedPhone,
        amount = amount,
        serviceFee = fee,
        totalAmount = total,
        notes = notes.trim(),
        transactionType = transactionType,
      )
    dao.insertTransaction(tx)
    return Result.success(tx)
  }

  fun calculateServiceFee(amount: Double): Double {
    return when {
      amount <= 0.0 -> 0.0
      amount <= 50.0 -> 1.00
      amount <= 500.0 -> 2.00
      amount <= 2000.0 -> 5.00
      else -> 10.00
    }
  }

  private fun createTransactionRecord(
    recipientName: String,
    recipientPhone: String,
    amount: Double,
    serviceFee: Double,
    totalAmount: Double,
    notes: String,
    transactionType: String,
  ): TransactionEntity {
    val now = System.currentTimeMillis()
    val formatter = SimpleDateFormat("yyyy/MM/dd HH:mm:ss", Locale.US)
    val txId = generateTransactionNumber()
    return TransactionEntity(
      transactionNumber = txId,
      recipientName = recipientName,
      recipientPhone = recipientPhone,
      amount = amount,
      serviceFee = serviceFee,
      totalAmount = totalAmount,
      notes = notes,
      transactionType = transactionType,
      formattedTime = formatter.format(Date(now)),
      timestampMillis = now,
    )
  }

  private fun generateTransactionNumber(): String {
    val chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    return buildString {
      append("DKM")
      repeat(7) { append(chars[Random.nextInt(chars.length)]) }
    }
  }

  companion object {
    fun normalizeEthiopianPhone(raw: String): String {
      val digits = raw.filter { it.isDigit() }
      return when {
        digits.startsWith("251") -> digits
        digits.startsWith("0") && digits.length >= 10 -> "251" + digits.drop(1)
        digits.isNotEmpty() -> "251$digits"
        else -> "251900000000"
      }
    }

    fun maskPhone(phone: String): String {
      val clean = phone.filter { it.isDigit() }
      return if (clean.length >= 8) {
        "${clean.take(4)}****${clean.takeLast(4)}"
      } else {
        clean
      }
    }
  }
}
