package com.example.util

import android.content.ContentValues
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color as AndroidColor
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import com.example.data.TransactionEntity
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.Locale

object ReceiptDownloadHelper {

  fun buildReceiptFileName(transactionNumber: String, extension: String = "png"): String {
    val sanitized = transactionNumber.trim().replace(Regex("[^A-Za-z0-9_-]"), "_")
    val base = if (sanitized.isBlank()) "receipt" else sanitized
    val ext = extension.trim().trimStart('.').ifBlank { "png" }
    return "telebirr_receipt_${base}.$ext"
  }

  fun buildReceiptShareText(transaction: TransactionEntity): String =
    buildString {
      appendLine("telebirr Transaction Receipt")
      appendLine("Status: Successful")
      appendLine("Amount: -${String.format(Locale.US, "%.2f", transaction.totalAmount)} (ETB)")
      appendLine("Transaction Time: ${transaction.formattedTime}")
      appendLine("Transaction Type: ${transaction.transactionType}")
      appendLine("Transaction To: ${transaction.recipientName}")
      appendLine("Recipient Number: ${transaction.recipientPhone}")
      appendLine("Transaction Number: ${transaction.transactionNumber}")
      if (transaction.notes.isNotBlank()) {
        appendLine("Notes: ${transaction.notes}")
      }
    }

  fun saveReceiptImageToDownloads(
    context: Context,
    transaction: TransactionEntity,
  ): Result<String> {
    val fileName = buildReceiptFileName(transaction.transactionNumber, "png")
    val bitmap = renderReceiptBitmap(transaction)
    return try {
      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val resolver = context.contentResolver
        val values =
          ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "image/png")
            put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            put(MediaStore.Downloads.IS_PENDING, 1)
          }
        val uri =
          resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, values)
            ?: return Result.failure(IOException("Unable to create file in Downloads"))
        try {
          val stream =
            resolver.openOutputStream(uri)
              ?: throw IOException("Unable to open output stream for $fileName")
          stream.use { out ->
            if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
              throw IOException("Failed to encode receipt image")
            }
          }
          val publishValues =
            ContentValues().apply {
              put(MediaStore.Downloads.IS_PENDING, 0)
            }
          resolver.update(uri, publishValues, null, null)
          Result.success("Downloads/$fileName")
        } catch (e: Exception) {
          resolver.delete(uri, null, null)
          Result.failure(e)
        }
      } else {
        val downloadsDir =
          context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) ?: context.filesDir
        if (!downloadsDir.exists() && !downloadsDir.mkdirs()) {
          return Result.failure(IOException("Unable to access Downloads directory"))
        }
        val outFile = File(downloadsDir, fileName)
        FileOutputStream(outFile).use { out ->
          if (!bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)) {
            throw IOException("Failed to encode receipt image")
          }
        }
        Result.success(outFile.name)
      }
    } catch (e: Exception) {
      Result.failure(e)
    } finally {
      bitmap.recycle()
    }
  }

  private fun renderReceiptBitmap(transaction: TransactionEntity): Bitmap {
    val width = 1080
    val height = 1380
    val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
    val canvas = Canvas(bitmap)
    canvas.drawColor(AndroidColor.WHITE)

    val telebirrGreen = AndroidColor.rgb(140, 198, 63)
    val telebirrBlue = AndroidColor.rgb(0, 114, 188)
    val textPrimary = AndroidColor.rgb(26, 28, 30)
    val textSecondary = AndroidColor.rgb(122, 128, 134)
    val dividerColor = AndroidColor.rgb(235, 238, 240)

    val brandPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = telebirrBlue
        textSize = 40f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
      }
    canvas.drawText("telebirr SuperApp E-Receipt", width / 2f, 110f, brandPaint)

    val circlePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = telebirrGreen
        style = Paint.Style.FILL
      }
    canvas.drawCircle(width / 2f, 225f, 58f, circlePaint)

    val checkPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.WHITE
        strokeWidth = 10f
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
        style = Paint.Style.STROKE
      }
    canvas.drawLine(width / 2f - 24f, 226f, width / 2f - 6f, 244f, checkPaint)
    canvas.drawLine(width / 2f - 6f, 244f, width / 2f + 26f, 206f, checkPaint)

    val statusPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = telebirrGreen
        textSize = 40f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
      }
    canvas.drawText("Successful", width / 2f, 336f, statusPaint)

    val amountPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = AndroidColor.BLACK
        textSize = 78f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.CENTER
      }
    val formattedTotal = "-${String.format(Locale.US, "%.2f", transaction.totalAmount)} (ETB)"
    canvas.drawText(formattedTotal, width / 2f, 475f, amountPaint)

    val linePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = dividerColor
        strokeWidth = 3f
      }
    canvas.drawLine(72f, 560f, width - 72f, 560f, linePaint)

    val labelPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textSecondary
        textSize = 36f
        textAlign = Paint.Align.LEFT
      }
    val valuePaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textPrimary
        textSize = 36f
        typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        textAlign = Paint.Align.RIGHT
      }

    val rows =
      buildList {
        add("Transaction Time:" to transaction.formattedTime)
        add("Transaction Type:" to transaction.transactionType)
        add("Transaction To:" to transaction.recipientName)
        add("Recipient Number:" to transaction.recipientPhone)
        add("Transaction Number:" to transaction.transactionNumber)
        add("Original Amount:" to "ETB ${String.format(Locale.US, "%.2f", transaction.amount)}")
        add("Service Fee:" to "ETB ${String.format(Locale.US, "%.2f", transaction.serviceFee)}")
        if (transaction.notes.isNotBlank()) {
          add("Notes:" to transaction.notes.take(40))
        }
      }

    var currentY = 640f
    rows.forEach { (label, value) ->
      canvas.drawText(label, 72f, currentY, labelPaint)
      canvas.drawText(value, width - 72f, currentY, valuePaint)
      currentY += 74f
    }

    canvas.drawLine(72f, height - 150f, width - 72f, height - 150f, linePaint)

    val footerPaint =
      Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = textSecondary
        textSize = 30f
        textAlign = Paint.Align.CENTER
      }
    canvas.drawText("Ethio telecom • telebirr SuperApp", width / 2f, height - 86f, footerPaint)

    return bitmap
  }
}
