package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.data.MiniAppItem
import com.example.data.TelebirrCatalog
import com.example.data.TelebirrDatabase
import com.example.data.TelebirrRepository
import com.example.ui.components.MainTab
import com.example.ui.components.TelebirrBottomBar
import com.example.ui.screens.AccountScreen
import com.example.ui.screens.AppsScreen
import com.example.ui.screens.CashInDialog
import com.example.ui.screens.EngageScreen
import com.example.ui.screens.GlobalSearchDialog
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.LoginScreen
import com.example.ui.screens.MiniAppDetailDialog
import com.example.ui.screens.NearbyAgentsDialog
import com.example.ui.screens.NotificationsInboxDialog
import com.example.ui.screens.PaymentScreen
import com.example.ui.screens.QrActionDialog
import com.example.ui.screens.SendMoneyAmountScreen
import com.example.ui.screens.SendMoneyRecipientScreen
import com.example.ui.screens.SplashScreen
import com.example.ui.screens.TelebirrSmsAlertOverlay
import com.example.ui.screens.TransactionReceiptScreen
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrTheme
import com.example.ui.viewmodel.TelebirrViewModel
import com.example.ui.viewmodel.TelebirrViewModelFactory
import kotlinx.coroutines.delay

object TelebirrRoutes {
  const val SPLASH = "splash"
  const val LOGIN = "login"
  const val MAIN = "main"
  const val SEND_RECIPIENT = "send_recipient"
  const val SEND_AMOUNT = "send_amount"
  const val RECEIPT = "receipt"
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()

    val database = TelebirrDatabase.getInstance(applicationContext)
    val repository = TelebirrRepository(database.telebirrDao())
    val factory = TelebirrViewModelFactory(repository)

    setContent {
      TelebirrTheme {
        val viewModel: TelebirrViewModel = viewModel(factory = factory)
        TelebirrAppRoot(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun TelebirrAppRoot(viewModel: TelebirrViewModel) {
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()
  val navController = rememberNavController()
  val snackbarHostState = remember { SnackbarHostState() }

  var currentTab by rememberSaveable { mutableStateOf(MainTab.HOME) }
  var showCashInDialog by remember { mutableStateOf(false) }
  var showNotificationsDialog by remember { mutableStateOf(false) }
  var showQrDialog by remember { mutableStateOf(false) }
  var showSearchDialog by remember { mutableStateOf(false) }
  var showAgentsDialog by remember { mutableStateOf(false) }
  var selectedMiniApp by remember { mutableStateOf<MiniAppItem?>(null) }

  LaunchedEffect(uiState.infoBannerMessage) {
    val msg = uiState.infoBannerMessage
    if (msg != null) {
      snackbarHostState.showSnackbar(msg)
      viewModel.clearInfoBanner()
    }
  }

  LaunchedEffect(uiState.activeSmsBanner?.id) {
    if (uiState.activeSmsBanner != null) {
      delay(7000L)
      viewModel.dismissSmsBanner()
    }
  }

  val isAmharic =
    uiState.wallet.language.contains("አማርኛ") ||
      uiState.wallet.language.contains("Amharic", ignoreCase = true)

  CompositionLocalProvider(LocalIsAmharic provides isAmharic) {
    Box(modifier = Modifier.fillMaxSize()) {
      Scaffold(
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
      ) { innerPadding ->
      NavHost(
        navController = navController,
        startDestination = TelebirrRoutes.SPLASH,
        modifier = Modifier.fillMaxSize().padding(innerPadding),
      ) {
        composable(TelebirrRoutes.SPLASH) {
          SplashScreen(
            onFinished = {
              val nextRoute =
                if (uiState.wallet.isLoggedIn) TelebirrRoutes.MAIN else TelebirrRoutes.LOGIN
              navController.navigate(nextRoute) {
                popUpTo(TelebirrRoutes.SPLASH) { inclusive = true }
              }
            }
          )
        }

        composable(TelebirrRoutes.LOGIN) {
          LoginScreen(
            phoneInput = uiState.loginPhoneInput,
            selectedLanguage = uiState.wallet.language,
            errorMessage = uiState.errorMessage,
            onPhoneChange = viewModel::updateLoginPhone,
            onSelectLanguage = viewModel::selectLanguage,
            onLoginClick = {
              viewModel.login {
                currentTab = MainTab.HOME
                navController.navigate(TelebirrRoutes.MAIN) {
                  popUpTo(TelebirrRoutes.LOGIN) { inclusive = true }
                }
              }
            },
          )
        }

        composable(TelebirrRoutes.MAIN) {
          Scaffold(
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            bottomBar = {
              TelebirrBottomBar(
                currentTab = currentTab,
                onSelectTab = { currentTab = it },
              )
            },
          ) { mainPadding ->
            Box(modifier = Modifier.fillMaxSize().padding(mainPadding)) {
              when (currentTab) {
                MainTab.HOME ->
                  HomeScreen(
                    uiState = uiState,
                    onToggleBalance = viewModel::toggleBalanceVisibility,
                    onToggleEndekise = viewModel::toggleEndekiseVisibility,
                    onToggleReward = viewModel::toggleRewardVisibility,
                    onSelectLanguage = viewModel::selectLanguage,
                    onOpenSearch = { showSearchDialog = true },
                    onOpenNotifications = {
                      viewModel.markAllNotificationsRead()
                      showNotificationsDialog = true
                    },
                    onSendIndividual = {
                      viewModel.startSendMoneyFlow(transactionType = "Transfer Money")
                      navController.navigate(TelebirrRoutes.SEND_RECIPIENT)
                    },
                    onSendGroup = {
                      viewModel.startSendMoneyFlow(
                        recipientName = "Family Group",
                        recipientPhone = "911000001",
                        transactionType = "Group Transfer",
                      )
                      navController.navigate(TelebirrRoutes.SEND_RECIPIENT)
                    },
                    onOpenServiceAction = { serviceId ->
                      when (serviceId) {
                        "cash_in_out" -> showCashInDialog = true
                        "airtime" -> {
                          viewModel.startSendMoneyFlow(
                            recipientName = "Ethio telecom Airtime",
                            recipientPhone = uiState.wallet.phoneNumber,
                            transactionType = "Airtime/Buy Package",
                          )
                          navController.navigate(TelebirrRoutes.SEND_AMOUNT)
                        }
                        "zemen" -> {
                          selectedMiniApp =
                            MiniAppItem(
                              id = "zemen_gebeya",
                              title = "Zemen GEBEYA",
                              iconKey = "zemen_dispatch",
                              description =
                                "Where Ethiopia Shops Digitally. Browse verified merchants and checkout with telebirr.",
                              category = "E-commerce",
                            )
                        }
                        "dashen" -> {
                          viewModel.startSendMoneyFlow(
                            recipientName = "Dashen Bank Account",
                            recipientPhone = "911220001",
                            transactionType = "Dashen Financial Service",
                          )
                          navController.navigate(TelebirrRoutes.SEND_AMOUNT)
                        }
                        "cbe" -> {
                          viewModel.startSendMoneyFlow(
                            recipientName = "CBE Bank Account",
                            recipientPhone = "911220002",
                            transactionType = "CBE Financial Service",
                          )
                          navController.navigate(TelebirrRoutes.SEND_AMOUNT)
                        }
                        "siinqee" -> {
                          viewModel.startSendMoneyFlow(
                            recipientName = "Siinqee Bank Account",
                            recipientPhone = "911220003",
                            transactionType = "Siinqee Financial Service",
                          )
                          navController.navigate(TelebirrRoutes.SEND_AMOUNT)
                        }
                        "transfer_bank" -> {
                          viewModel.startSendMoneyFlow(transactionType = "Transfer to Bank")
                          navController.navigate(TelebirrRoutes.SEND_RECIPIENT)
                        }
                      }
                    },
                    onScanQr = { showQrDialog = true },
                    onOpenLocationFinder = { showAgentsDialog = true },
                    onOpenFaydaBanner = {
                      selectedMiniApp =
                        TelebirrCatalog.miniApps.firstOrNull { it.id == "fayda_id" }
                    },
                    onOpenZemenBanner = {
                      selectedMiniApp =
                        MiniAppItem(
                          id = "zemen_gebeya",
                          title = "Zemen GEBEYA",
                          iconKey = "zemen_dispatch",
                          description =
                            "Where Ethiopia Shops Digitally. Shop electronics, groceries, and home essentials.",
                          category = "E-commerce",
                        )
                    },
                    onOpenTransaction = { tx ->
                      viewModel.openTransactionReceipt(tx)
                      navController.navigate(TelebirrRoutes.RECEIPT)
                    },
                  )

                MainTab.PAYMENT ->
                  PaymentScreen(
                    onSelectService = { service ->
                      viewModel.startSendMoneyFlow(
                        recipientName = service.title.replace("\n", " "),
                        recipientPhone = "900100100",
                        transactionType = "Pay Bill (${service.categoryTitle})",
                      )
                      navController.navigate(TelebirrRoutes.SEND_AMOUNT)
                    }
                  )

                MainTab.APPS ->
                  AppsScreen(
                    onOpenMiniApp = { app -> selectedMiniApp = app },
                  )

                MainTab.ENGAGE ->
                  EngageScreen(
                    recentRecipients = uiState.recentRecipients,
                    onSendGiftToContact = { recipient ->
                      viewModel.startSendMoneyFlow(transactionType = "Engage Transfer")
                      viewModel.selectRecentRecipient(recipient)
                      navController.navigate(TelebirrRoutes.SEND_AMOUNT)
                    },
                    onOpenSearch = { showSearchDialog = true },
                  )

                MainTab.ACCOUNT ->
                  AccountScreen(
                    wallet = uiState.wallet,
                    transactions = uiState.transactions,
                    onSelectLanguage = viewModel::selectLanguage,
                    onShowMyQr = { showQrDialog = true },
                    onOpenSearch = { showSearchDialog = true },
                    onLogout = {
                      viewModel.logout {
                        navController.navigate(TelebirrRoutes.LOGIN) {
                          popUpTo(TelebirrRoutes.MAIN) { inclusive = true }
                        }
                      }
                    },
                  )
              }
            }
          }
        }

        composable(TelebirrRoutes.SEND_RECIPIENT) {
          SendMoneyRecipientScreen(
            recipientName = uiState.sendDraft.recipientName,
            recipientPhone = uiState.sendDraft.recipientPhone,
            recentRecipients = uiState.recentRecipients,
            onBack = { navController.popBackStack() },
            onDetailsChange = viewModel::updateRecipientDetails,
            onNext = { navController.navigate(TelebirrRoutes.SEND_AMOUNT) },
            onSelectRecent = { recipient ->
              viewModel.selectRecentRecipient(recipient)
              navController.navigate(TelebirrRoutes.SEND_AMOUNT)
            },
            onClearRecent = viewModel::clearRecentRecipients,
            onScanQrClick = { showQrDialog = true },
          )
        }

        composable(TelebirrRoutes.SEND_AMOUNT) {
          val numericAmount = uiState.sendDraft.amountInput.toDoubleOrNull() ?: 0.0
          val fee = viewModel.calculateFee(numericAmount)
          SendMoneyAmountScreen(
            draft = uiState.sendDraft,
            availableBalance = uiState.wallet.balance,
            serviceFee = fee,
            errorMessage = uiState.errorMessage,
            isProcessing = uiState.isProcessing,
            onBack = { navController.popBackStack() },
            onEditRecipientDetails = viewModel::updateRecipientDetails,
            onKeypadPress = viewModel::onKeypadPress,
            onNotesChange = viewModel::updateNotes,
            onConfirmSend = {
              viewModel.confirmSendMoney {
                navController.navigate(TelebirrRoutes.RECEIPT) {
                  popUpTo(TelebirrRoutes.MAIN) { inclusive = false }
                }
              }
            },
            onDismissError = viewModel::clearError,
          )
        }

        composable(TelebirrRoutes.RECEIPT) {
          val receipt = uiState.activeReceipt
          if (receipt != null) {
            TransactionReceiptScreen(
              transaction = receipt,
              onDownloadMessage = viewModel::showInfoMessage,
              onFinished = {
                currentTab = MainTab.HOME
                navController.popBackStack(TelebirrRoutes.MAIN, inclusive = false)
              },
            )
          }
        }
      }
    }

    // Floating Truecaller-style SMS notification toast when transfer finishes
    TelebirrSmsAlertOverlay(
      smsBanner = uiState.activeSmsBanner,
      onDismiss = viewModel::dismissSmsBanner,
      modifier = Modifier.align(Alignment.TopCenter),
    )
  }

  if (showCashInDialog) {
    CashInDialog(
      onDismiss = { showCashInDialog = false },
      onConfirmCashIn = { amount ->
        viewModel.performCashIn(amount) { showCashInDialog = false }
      },
    )
  }

  if (showNotificationsDialog) {
    NotificationsInboxDialog(
      items = uiState.smsNotifications,
      onDismiss = { showNotificationsDialog = false },
    )
  }

  if (showQrDialog) {
    QrActionDialog(
      userName = uiState.wallet.userName,
      phoneNumber = uiState.wallet.phoneNumber,
      onDismiss = { showQrDialog = false },
      onScanPayMerchant = {
        showQrDialog = false
        viewModel.startSendMoneyFlow(
          recipientName = "Telebirr Merchant",
          recipientPhone = "911880011",
          transactionType = "QR Merchant Payment",
        )
        navController.navigate(TelebirrRoutes.SEND_AMOUNT)
      },
    )
  }

  if (selectedMiniApp != null) {
    val app = selectedMiniApp!!
    MiniAppDetailDialog(
      app = app,
      onDismiss = { selectedMiniApp = null },
      onPayWithTelebirr = { chosen ->
        selectedMiniApp = null
        viewModel.startSendMoneyFlow(
          recipientName = chosen.title.replace("\n", " "),
          recipientPhone = "900200300",
          transactionType = "MiniApp Payment",
        )
        navController.navigate(TelebirrRoutes.SEND_AMOUNT)
      },
    )
  }

  if (showSearchDialog) {
    GlobalSearchDialog(
      onDismiss = { showSearchDialog = false },
      onSelectMiniApp = { chosen ->
        showSearchDialog = false
        selectedMiniApp = chosen
      },
    )
  }

  if (showAgentsDialog) {
    NearbyAgentsDialog(onDismiss = { showAgentsDialog = false })
  }
  }
}
