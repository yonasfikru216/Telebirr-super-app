package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.RecipientEntity
import com.example.ui.components.RecipientAvatar
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrDivider
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary

@Composable
fun EngageScreen(
  recentRecipients: List<RecipientEntity>,
  onSendGiftToContact: (RecipientEntity) -> Unit,
  onOpenSearch: () -> Unit,
) {
  var showEngageHubDialog by remember { mutableStateOf(false) }

  Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(TelebirrGreen)
          .statusBarsPadding()
          .padding(horizontal = 8.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(
        onClick = { showEngageHubDialog = true },
        modifier = Modifier.size(40.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Menu,
          contentDescription = "Engage Menu",
          tint = Color.White,
        )
      }
      Text(
        text = "Engage",
        fontSize = 19.sp,
        fontWeight = FontWeight.Medium,
        color = Color.White,
        textAlign = TextAlign.Center,
        modifier = Modifier.weight(1f),
      )
      IconButton(
        onClick = onOpenSearch,
        modifier = Modifier.size(40.dp),
      ) {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = "Search Engage",
          tint = Color.White,
        )
      }
    }

    Column(
      modifier = Modifier.fillMaxSize().padding(horizontal = 32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.Center,
    ) {
      Image(
        painter = painterResource(id = R.drawable.img_engage_logo),
        contentDescription = "telebirr Engage",
        modifier = Modifier.size(164.dp),
        contentScale = ContentScale.Fit,
      )

      Spacer(modifier = Modifier.height(22.dp))

      Text(
        text = "Welcome to telebirr Engage",
        fontSize = 19.sp,
        fontWeight = FontWeight.Bold,
        color = Color.Black,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(44.dp))

      Text(
        text = "Engage with your friends\nand family and experience\nthe power of telebirr!!",
        fontSize = 16.sp,
        lineHeight = 22.sp,
        color = TelebirrTextSecondary,
        textAlign = TextAlign.Center,
      )

      Spacer(modifier = Modifier.height(74.dp))

      Button(
        onClick = { showEngageHubDialog = true },
        shape = RoundedCornerShape(10.dp),
        colors =
          ButtonDefaults.buttonColors(
            containerColor = TelebirrGreen,
            contentColor = Color.White,
          ),
        modifier =
          Modifier.width(196.dp)
            .height(50.dp)
            .testTag("engage_start_button"),
      ) {
        Text(
          text = "Start Engaging",
          fontSize = 16.sp,
          fontWeight = FontWeight.SemiBold,
        )
      }
    }
  }

  if (showEngageHubDialog) {
    AlertDialog(
      onDismissRequest = { showEngageHubDialog = false },
      title = { Text("telebirr Engage Circles", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text(
            "Select a friend or family member to send money or share a bill:",
            fontSize = 13.sp,
            color = TelebirrTextSecondary,
          )
          HorizontalDivider(color = TelebirrDivider)
          recentRecipients.take(5).forEach { contact ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable {
                    showEngageHubDialog = false
                    onSendGiftToContact(contact)
                  }
                  .padding(vertical = 8.dp, horizontal = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RecipientAvatar(avatarKey = contact.avatarKey, size = 34.dp)
              Spacer(modifier = Modifier.width(10.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(contact.name, fontWeight = FontWeight.SemiBold, color = TelebirrTextPrimary)
                Text("+${contact.phoneNumber}", fontSize = 12.sp, color = TelebirrTextSecondary)
              }
              Text("Send", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TelebirrGreen)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showEngageHubDialog = false }) {
          Text("Close", color = TelebirrBlue)
        }
      },
    )
  }
}
