package com.example.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.AirplanemodeActive
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DirectionsRun
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.EventAvailable
import androidx.compose.material.icons.filled.FlightTakeoff
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.HomeWork
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.ReceiptLong
import androidx.compose.material.icons.filled.Recycling
import androidx.compose.material.icons.filled.Router
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material.icons.filled.ShoppingBag
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material.icons.filled.Storefront
import androidx.compose.material.icons.filled.Train
import androidx.compose.material.icons.filled.Tv
import androidx.compose.material.icons.filled.VolunteerActivism
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrGold
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrGreenDeep
import com.example.ui.theme.TelebirrGreenLight
import com.example.ui.theme.TelebirrOrange

@Composable
fun ConcentricCirclesBackground(
  modifier: Modifier = Modifier,
  baseGradient: List<Color> = listOf(TelebirrGreen, TelebirrGreenDeep),
) {
  Canvas(modifier = modifier.background(Brush.verticalGradient(baseGradient))) {
    val ringColor = Color.White.copy(alpha = 0.08f)
    val stroke = Stroke(width = size.minDimension * 0.035f)
    val centers =
      listOf(
        Offset(size.width * 0.12f, size.height * 0.22f),
        Offset(size.width * 0.85f, size.height * 0.15f),
        Offset(size.width * 0.52f, size.height * 0.72f),
        Offset(size.width * 0.18f, size.height * 0.88f),
      )
    centers.forEach { center ->
      for (i in 1..5) {
        drawCircle(
          color = ringColor,
          radius = size.minDimension * (0.12f * i),
          center = center,
          style = stroke,
        )
      }
    }
  }
}

@Composable
fun LoginWavesBackground(modifier: Modifier = Modifier) {
  Canvas(modifier = modifier.background(Color(0xFFFDFEFB))) {
    val waveColor = Color(0xFF9AC580).copy(alpha = 0.13f)
    val lineStroke = Stroke(width = 1.6f)
    // Top-left concentric wave arcs
    for (i in 1..18) {
      drawCircle(
        color = waveColor,
        radius = size.width * (0.18f + i * 0.028f),
        center = Offset(-size.width * 0.12f, size.height * 0.34f),
        style = lineStroke,
      )
    }
    // Bottom-right concentric wave arcs
    for (i in 1..16) {
      drawCircle(
        color = waveColor,
        radius = size.width * (0.15f + i * 0.026f),
        center = Offset(size.width * 0.92f, size.height * 0.88f),
        style = lineStroke,
      )
    }
  }
}

@Composable
fun TelebirrTopBrandHeader(
  modifier: Modifier = Modifier,
  applyStatusBarPadding: Boolean = true,
) {
  Row(
    modifier =
      modifier
        .fillMaxWidth()
        .background(Color.White)
        .then(if (applyStatusBarPadding) Modifier.statusBarsPadding() else Modifier)
        .padding(horizontal = 16.dp, vertical = 10.dp),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    // Left: ethio telecom brand lockup
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
      Box(
        modifier =
          Modifier.size(30.dp)
            .clip(CircleShape)
            .background(
              Brush.linearGradient(
                colors = listOf(TelebirrGreen, Color(0xFF56B330), TelebirrBlue)
              )
            ),
        contentAlignment = Alignment.Center,
      ) {
        Box(
          modifier =
            Modifier.size(16.dp)
              .clip(CircleShape)
              .background(Color.White.copy(alpha = 0.28f))
        )
      }
      androidx.compose.foundation.layout.Column {
        Text(
          text = "ethio telecom™",
          fontSize = 14.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF1F2329),
          lineHeight = 16.sp,
        )
        Text(
          text = "ኢትዮ ቴሌኮም",
          fontSize = 8.sp,
          fontWeight = FontWeight.Medium,
          color = Color(0xFF6B7280),
          lineHeight = 10.sp,
        )
      }
    }

    // Right: telebirr swirl + Amharic/English text
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp)) {
      Image(
        painter = painterResource(id = R.drawable.ic_telebirr_swirl),
        contentDescription = "Telebirr logo",
        modifier = Modifier.size(30.dp),
        contentScale = ContentScale.Fit,
      )
      androidx.compose.foundation.layout.Column {
        Text(
          text = "ቴሌብር",
          fontSize = 11.sp,
          fontWeight = FontWeight.Bold,
          color = TelebirrBlue,
          lineHeight = 12.sp,
        )
        Text(
          text = "telebirr",
          fontSize = 12.sp,
          fontWeight = FontWeight.Bold,
          color = TelebirrGold,
          lineHeight = 13.sp,
        )
      }
    }
  }
}

@Composable
fun RecipientAvatar(
  avatarKey: String,
  size: Dp = 44.dp,
  cornerRadius: Dp = 8.dp,
) {
  when (avatarKey) {
    "solomon" ->
      Image(
        painter = painterResource(id = R.drawable.avatar_solomon),
        contentDescription = "Recipient avatar",
        modifier = Modifier.size(size).clip(RoundedCornerShape(cornerRadius)),
        contentScale = ContentScale.Crop,
      )
    "kene" ->
      Image(
        painter = painterResource(id = R.drawable.avatar_kene),
        contentDescription = "Recipient avatar",
        modifier = Modifier.size(size).clip(RoundedCornerShape(cornerRadius)),
        contentScale = ContentScale.Crop,
      )
    "fikiru" ->
      Image(
        painter = painterResource(id = R.drawable.avatar_fikiru),
        contentDescription = "User profile avatar",
        modifier = Modifier.size(size).clip(RoundedCornerShape(cornerRadius)),
        contentScale = ContentScale.Crop,
      )
    else ->
      Box(
        modifier =
          Modifier.size(size)
            .clip(RoundedCornerShape(cornerRadius))
            .background(Color(0xFFFED000)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.Person,
          contentDescription = "Recipient icon",
          tint = Color.White,
          modifier = Modifier.size(size * 0.68f),
        )
      }
  }
}

@Composable
fun HomeServiceIcon(iconKey: String) {
  when (iconKey) {
    "send_money" ->
      Icon(
        imageVector = Icons.Outlined.AccountBalanceWallet,
        contentDescription = null,
        tint = TelebirrGreen,
        modifier = Modifier.size(30.dp),
      )
    "cash_in_out" ->
      Icon(
        imageVector = Icons.Filled.AccountBalanceWallet,
        contentDescription = null,
        tint = TelebirrGreen,
        modifier = Modifier.size(30.dp),
      )
    "airtime" ->
      Icon(
        imageVector = Icons.Filled.CardGiftcard,
        contentDescription = null,
        tint = TelebirrGreen,
        modifier = Modifier.size(30.dp),
      )
    "zemen" ->
      Box(
        modifier = Modifier.size(38.dp).clip(CircleShape).background(Color(0xFF0A3B24)),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "ዘመን\nGEBEYA",
          fontSize = 7.sp,
          lineHeight = 8.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFFEBD27A),
          textAlign = TextAlign.Center,
        )
      }
    "dashen" ->
      Box(
        modifier =
          Modifier.size(34.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF14357A)),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "ዳሸን\nBANK",
          fontSize = 7.sp,
          lineHeight = 8.sp,
          fontWeight = FontWeight.Bold,
          color = Color.White,
          textAlign = TextAlign.Center,
        )
      }
    "cbe" ->
      Box(
        modifier =
          Modifier.size(34.dp)
            .clip(CircleShape)
            .background(Color(0xFFF6E7C8))
            .border(1.5.dp, Color(0xFF7B4D25), CircleShape),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "CBE",
          fontSize = 10.sp,
          fontWeight = FontWeight.ExtraBold,
          color = Color(0xFF6B3E17),
        )
      }
    "siinqee" ->
      Box(
        modifier =
          Modifier.size(34.dp)
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFFF5F3EE))
            .border(1.dp, Color(0xFFD9C7A3), RoundedCornerShape(6.dp)),
        contentAlignment = Alignment.Center,
      ) {
        Text(
          text = "Siinqee",
          fontSize = 8.sp,
          fontWeight = FontWeight.Bold,
          color = Color(0xFF8C5319),
        )
      }
    "transfer_bank" ->
      Icon(
        imageVector = Icons.Filled.AccountBalance,
        contentDescription = null,
        tint = TelebirrGreen,
        modifier = Modifier.size(30.dp),
      )
    else ->
      Icon(
        imageVector = Icons.Filled.AccountBalanceWallet,
        contentDescription = null,
        tint = TelebirrGreen,
        modifier = Modifier.size(30.dp),
      )
  }
}

@Composable
fun PaymentServiceBadge(iconKey: String) {
  when (iconKey) {
    "ethio" ->
      Box(
        modifier =
          Modifier.size(38.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(TelebirrGreen, TelebirrBlue))),
        contentAlignment = Alignment.Center,
      ) {
        Text("e", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 18.sp)
      }
    "eeu", "eeu_alt" ->
      Box(
        modifier =
          Modifier.size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFFF59E0B).copy(alpha = 0.16f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Bolt, null, tint = Color(0xFFE07B00), modifier = Modifier.size(22.dp))
      }
    "aawsa" ->
      Box(
        modifier =
          Modifier.size(38.dp)
            .clip(CircleShape)
            .border(1.5.dp, Color(0xFF1E5AA8), CircleShape)
            .background(Color(0xFFEBF5FF)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.WaterDrop, null, tint = Color(0xFF1E5AA8), modifier = Modifier.size(20.dp))
      }
    "derash" ->
      Box(
        modifier =
          Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFD92D20)),
        contentAlignment = Alignment.Center,
      ) {
        Text("D", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 16.sp)
      }
    "webirr" ->
      Box(
        modifier =
          Modifier.size(38.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF1F2937)),
        contentAlignment = Alignment.Center,
      ) {
        Text("We", color = TelebirrGreenLight, fontWeight = FontWeight.Bold, fontSize = 12.sp)
      }
    "wm" ->
      Box(
        modifier =
          Modifier.size(38.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFC5E1A5)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Recycling, null, tint = Color(0xFF2E7D32), modifier = Modifier.size(22.dp))
      }
    "unicash" ->
      Box(
        modifier =
          Modifier.size(38.dp)
            .clip(CircleShape)
            .border(3.dp, Color(0xFF16A34A), CircleShape)
            .background(Color(0xFFFEF3C7)),
        contentAlignment = Alignment.Center,
      ) {
        Text("C", color = Color(0xFF15803D), fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
      }
    "websprix" ->
      Box(
        modifier =
          Modifier.size(38.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFF111111)),
        contentAlignment = Alignment.Center,
      ) {
        Text("WS", color = Color(0xFFFACC15), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
      }
    "palaba" ->
      Box(
        modifier =
          Modifier.size(38.dp).clip(CircleShape).background(Color(0xFFE0F2FE)),
        contentAlignment = Alignment.Center,
      ) {
        Text("Po", color = Color(0xFF0369A1), fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
      }
    else -> {
      val (icon, tint, bg) =
        when (iconKey) {
          "gov", "mesob" -> Triple(Icons.Filled.AccountBalance, TelebirrBlue, Color(0xFFE6F3FB))
          "train", "bus" -> Triple(Icons.Filled.DirectionsBus, Color(0xFF0284C7), Color(0xFFE0F2FE))
          "ride" -> Triple(Icons.Filled.DirectionsCar, Color(0xFFD97706), Color(0xFFFEF3C7))
          "toll" -> Triple(Icons.Filled.ReceiptLong, Color(0xFF4B5563), Color(0xFFF3F4F6))
          "dstv", "tv", "cinema" -> Triple(Icons.Filled.Tv, Color(0xFF1D4ED8), Color(0xFFDBEAFE))
          "zemen", "zmall", "ashewa" -> Triple(Icons.Filled.ShoppingBag, TelebirrGreenDeep, Color(0xFFEAF5DC))
          "ger", "ticket" -> Triple(Icons.Filled.DirectionsRun, Color(0xFF16A34A), Color(0xFFDCFCE7))
          "edu" -> Triple(Icons.Filled.School, Color(0xFF4F46E5), Color(0xFFE0E7FF))
          "fund" -> Triple(Icons.Filled.VolunteerActivism, Color(0xFFDC2626), Color(0xFFFEE2E2))
          "traffic" -> Triple(Icons.Filled.Gavel, Color(0xFFB45309), Color(0xFFFEF3C7))
          "insurance" -> Triple(Icons.Filled.Shield, Color(0xFF0F766E), Color(0xFFCCFBF1))
          "agri" -> Triple(Icons.Filled.HomeWork, Color(0xFF15803D), Color(0xFFDCFCE7))
          "health" -> Triple(Icons.Filled.LocalHospital, Color(0xFFE11D48), Color(0xFFFFE4E6))
          else -> Triple(Icons.Filled.CreditCard, TelebirrGreen, Color(0xFFEAF5DC))
        }
      Box(
        modifier = Modifier.size(38.dp).clip(CircleShape).background(bg),
        contentAlignment = Alignment.Center,
      ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(20.dp))
      }
    }
  }
}

@Composable
fun MiniAppBadge(iconKey: String) {
  when (iconKey) {
    "ethio" -> PaymentServiceBadge("ethio")
    "remit" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFEFF8FF)),
        contentAlignment = Alignment.Center,
      ) {
        Image(
          painter = painterResource(id = R.drawable.ic_telebirr_swirl),
          contentDescription = null,
          modifier = Modifier.size(28.dp),
        )
      }
    "tele_online" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFEAF5DC)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Router, null, tint = TelebirrGreenDeep, modifier = Modifier.size(24.dp))
      }
    "airlines" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFFEF9E7)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.FlightTakeoff, null, tint = Color(0xFF15803D), modifier = Modifier.size(24.dp))
      }
    "fayda", "fayda_print" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF0B3B59)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Badge, null, tint = Color.White, modifier = Modifier.size(22.dp))
      }
    "esl" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE6F4EA)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.LocalShipping, null, tint = Color(0xFF14532D), modifier = Modifier.size(22.dp))
      }
    "teninete" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFE0F2FE)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.LocalHospital, null, tint = Color(0xFF0284C7), modifier = Modifier.size(22.dp))
      }
    "dstv" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF0057A8)),
        contentAlignment = Alignment.Center,
      ) {
        Text("DStv", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
      }
    "howlow" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFF0FDF4)),
        contentAlignment = Alignment.Center,
      ) {
        Text("HW", color = TelebirrGreenDeep, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
      }
    "sitota" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFECFDF5)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.CardGiftcard, null, tint = Color(0xFF16A34A), modifier = Modifier.size(22.dp))
      }
    "eservices" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF1D4ED8)),
        contentAlignment = Alignment.Center,
      ) {
        Text("ET", color = TelebirrGold, fontWeight = FontWeight.ExtraBold, fontSize = 14.sp)
      }
    "ger" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFFEF3C7)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.DirectionsRun, null, tint = Color(0xFF16A34A), modifier = Modifier.size(24.dp))
      }
    "medhin" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFE0F2FE)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.HealthAndSafety, null, tint = Color(0xFF0369A1), modifier = Modifier.size(22.dp))
      }
    "ride" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFFACC15)),
        contentAlignment = Alignment.Center,
      ) {
        Text("RIDE", color = Color(0xFF111827), fontWeight = FontWeight.ExtraBold, fontSize = 10.sp)
      }
    "public_transport" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFEFF6FF)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.DirectionsBus, null, tint = Color(0xFF2563EB), modifier = Modifier.size(22.dp))
      }
    "hulu_beje" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF7C2D12)),
        contentAlignment = Alignment.Center,
      ) {
        Text("HB", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 15.sp)
      }
    "websprix" -> PaymentServiceBadge("websprix")
    "zmall" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFDC2626)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.ShoppingCart, null, tint = Color.White, modifier = Modifier.size(20.dp))
      }
    "equb" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFDCFCE7)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Groups, null, tint = Color(0xFF15803D), modifier = Modifier.size(22.dp))
      }
    "ashewa" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFFEF2F2)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Storefront, null, tint = Color(0xFF16A34A), modifier = Modifier.size(22.dp))
      }
    "act" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF0284C7)),
        contentAlignment = Alignment.Center,
      ) {
        Text("ACT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
      }
    "afroread" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF581C87)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.MenuBook, null, tint = Color(0xFFFDE047), modifier = Modifier.size(22.dp))
      }
    "shofer" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(TelebirrGreen),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.DirectionsCar, null, tint = Color.White, modifier = Modifier.size(22.dp))
      }
    "edr" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFECFDF5)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.Train, null, tint = Color(0xFF047857), modifier = Modifier.size(22.dp))
      }
    "teledrive" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFE0F2FE)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.CloudUpload, null, tint = TelebirrGreenDeep, modifier = Modifier.size(22.dp))
      }
    "zemen_dispatch" ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFF0A3B24)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.LocalShipping, null, tint = Color(0xFFEBD27A), modifier = Modifier.size(20.dp))
      }
    "qetero" ->
      Box(
        modifier = Modifier.size(42.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFFDF2F8)),
        contentAlignment = Alignment.Center,
      ) {
        Text("Q", color = Color(0xFFDB2777), fontWeight = FontWeight.ExtraBold, fontSize = 20.sp)
      }
    else ->
      Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color(0xFFEAF5DC)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(Icons.Filled.EventAvailable, null, tint = TelebirrGreenDeep, modifier = Modifier.size(22.dp))
      }
  }
}
