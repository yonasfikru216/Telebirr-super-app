package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.AccountBalanceWallet
import androidx.compose.material.icons.outlined.Groups
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.material.icons.outlined.ReceiptLong
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.TelebirrCatalog
import com.example.data.TransactionEntity
import com.example.ui.components.ConcentricCirclesBackground
import com.example.ui.components.HomeServiceIcon
import com.example.ui.components.RecipientAvatar
import com.example.ui.components.TelebirrTopBrandHeader
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrBackground
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrDivider
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrGreenDeep
import com.example.ui.theme.TelebirrOrange
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary
import com.example.ui.theme.TelebirrUiStrings
import com.example.ui.viewmodel.TelebirrUiState
import java.text.NumberFormat
import java.util.Locale

private data class HomeTile(
  val id: String,
  val label: String,
  val iconKey: String,
  val badge: String? = null,
)

private fun buildHomeTiles(strings: TelebirrUiStrings) =
  listOf(
    HomeTile("send_money", strings.tileSendMoney, "send_money"),
    HomeTile("cash_in_out", strings.tileCashInOut, "cash_in_out"),
    HomeTile("airtime", strings.tileAirtime, "airtime", badge = strings.tileAirtimeBadge),
    HomeTile("zemen", strings.tileZemen, "zemen"),
    HomeTile("dashen", strings.tileDashen, "dashen"),
    HomeTile("cbe", strings.tileCbe, "cbe"),
    HomeTile("siinqee", strings.tileSiinqee, "siinqee"),
    HomeTile("transfer_bank", strings.tileTransferBank, "transfer_bank"),
  )

@Composable
fun HomeScreen(
  uiState: TelebirrUiState,
  onToggleBalance: () -> Unit,
  onToggleEndekise: () -> Unit,
  onToggleReward: () -> Unit,
  onSelectLanguage: (String) -> Unit,
  onOpenSearch: () -> Unit,
  onOpenNotifications: () -> Unit,
  onSendIndividual: () -> Unit,
  onSendGroup: () -> Unit,
  onOpenServiceAction: (String) -> Unit,
  onScanQr: () -> Unit,
  onOpenLocationFinder: () -> Unit,
  onOpenFaydaBanner: () -> Unit,
  onOpenZemenBanner: () -> Unit,
  onOpenTransaction: (TransactionEntity) -> Unit,
) {
  val isAmharic = LocalIsAmharic.current
  val strings = TelebirrUiStrings.forLanguage(isAmharic)
  val homeTiles = remember(isAmharic) { buildHomeTiles(strings) }
  var showSendMenu by remember { mutableStateOf(false) }
  var showLangMenu by remember { mutableStateOf(false) }

  val numFmt =
    remember {
      NumberFormat.getNumberInstance(Locale.US).apply {
        minimumFractionDigits = 2
        maximumFractionDigits = 2
      }
    }
  val unreadCount = uiState.smsNotifications.count { it.isUnread }

  Box(modifier = Modifier.fillMaxSize().background(TelebirrBackground)) {
    LazyColumn(
      modifier = Modifier.fillMaxSize(),
      contentPadding = PaddingValues(bottom = 24.dp),
    ) {
      item {
        Column(modifier = Modifier.fillMaxWidth()) {
          // Green status strip + white brand bar
          Box(modifier = Modifier.fillMaxWidth().background(TelebirrGreen).statusBarsPadding())
          TelebirrTopBrandHeader(applyStatusBarPadding = false)

      // Green Dashboard Header with concentric circle pattern
      Box(modifier = Modifier.fillMaxWidth()) {
        ConcentricCirclesBackground(
          modifier = Modifier.matchParentSize(),
          baseGradient = listOf(TelebirrGreen, TelebirrGreenDeep),
        )

        Column(
          modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
          // User greeting row
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Box(
              modifier =
                Modifier.size(44.dp)
                  .clip(CircleShape)
                  .border(1.5.dp, Color.White.copy(alpha = 0.7f), CircleShape)
            ) {
              RecipientAvatar(avatarKey = "fikiru", size = 44.dp, cornerRadius = 22.dp)
            }
            Spacer(modifier = Modifier.width(12.dp))
            Text(
              text = "${strings.greetingPrefix}, ${uiState.wallet.userName}",
              fontSize = 17.sp,
              fontWeight = FontWeight.Medium,
              color = Color.White,
              modifier = Modifier.weight(1f),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
            )

            IconButton(
              onClick = onOpenSearch,
              modifier = Modifier.size(38.dp).testTag("home_search_button"),
            ) {
              Icon(
                imageVector = Icons.Filled.Search,
                contentDescription = "Search",
                tint = Color.White,
                modifier = Modifier.size(22.dp),
              )
            }

            Box {
              IconButton(
                onClick = onOpenNotifications,
                modifier = Modifier.size(38.dp).testTag("home_notifications_button"),
              ) {
                Icon(
                  imageVector = Icons.Filled.NotificationsNone,
                  contentDescription = "Notifications",
                  tint = Color.White,
                  modifier = Modifier.size(22.dp),
                )
              }
              if (unreadCount > 0) {
                Box(
                  modifier =
                    Modifier.align(Alignment.TopEnd)
                      .padding(top = 6.dp, end = 6.dp)
                      .size(8.dp)
                      .clip(CircleShape)
                      .background(TelebirrOrange)
                )
              }
            }

            Box {
              Row(
                modifier =
                  Modifier.clip(RoundedCornerShape(6.dp))
                    .clickable { showLangMenu = true }
                    .padding(horizontal = 4.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Text(
                  text =
                    if (uiState.wallet.language.startsWith("Eng")) "En.."
                    else uiState.wallet.language.take(3),
                  fontSize = 14.sp,
                  color = Color.White,
                  fontWeight = FontWeight.Medium,
                )
                Icon(
                  imageVector = Icons.Filled.ArrowDropDown,
                  contentDescription = "Language",
                  tint = Color.White,
                  modifier = Modifier.size(18.dp),
                )
              }
              DropdownMenu(expanded = showLangMenu, onDismissRequest = { showLangMenu = false }) {
                TelebirrCatalog.languages.forEach { lang ->
                  DropdownMenuItem(
                    text = { Text(lang) },
                    onClick = {
                      onSelectLanguage(lang)
                      showLangMenu = false
                    },
                  )
                }
              }
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          // Main Balance (ETB)
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = strings.balanceEtb,
              fontSize = 15.sp,
              fontWeight = FontWeight.Medium,
              color = Color.White.copy(alpha = 0.95f),
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              imageVector =
                if (uiState.showBalance) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
              contentDescription = "Toggle Balance Visibility",
              tint = Color.White,
              modifier =
                Modifier.size(18.dp)
                  .clickable { onToggleBalance() }
                  .testTag("toggle_balance_eye"),
            )
          }

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = if (uiState.showBalance) numFmt.format(uiState.wallet.balance) else "******",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().testTag("home_balance_text"),
          )

          Spacer(modifier = Modifier.height(16.dp))

          // Endekise and Reward Row
          Row(modifier = Modifier.fillMaxWidth()) {
            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = strings.endekiseEtb,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Medium,
                  color = Color.White.copy(alpha = 0.95f),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                  imageVector =
                    if (uiState.showEndekise) Icons.Filled.Visibility
                    else Icons.Filled.VisibilityOff,
                  contentDescription = "Toggle Endekise Visibility",
                  tint = Color.White,
                  modifier = Modifier.size(17.dp).clickable { onToggleEndekise() },
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text =
                  if (uiState.showEndekise) numFmt.format(uiState.wallet.endekise) else "******",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
              )
            }

            Column(modifier = Modifier.weight(1f)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                  text = strings.rewardEtb,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Medium,
                  color = Color.White.copy(alpha = 0.95f),
                )
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                  imageVector =
                    if (uiState.showReward) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                  contentDescription = "Toggle Reward Visibility",
                  tint = Color.White,
                  modifier = Modifier.size(17.dp).clickable { onToggleReward() },
                )
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                text = if (uiState.showReward) numFmt.format(uiState.wallet.reward) else "****",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
              )
            }
          }

          Spacer(modifier = Modifier.height(6.dp))
        }
      }

      // Orange Announcement Bar
      Box(
        modifier =
          Modifier.fillMaxWidth()
            .background(TelebirrOrange)
            .padding(vertical = 5.dp, horizontal = 12.dp)
      ) {
        Text(
          text = strings.marqueeText,
          fontSize = 12.sp,
          fontWeight = FontWeight.ExtraBold,
          color = Color.White,
          maxLines = 1,
          modifier = Modifier.fillMaxWidth().basicMarquee(),
        )
      }

      // White Rounded Main Body
      Surface(
        modifier = Modifier.fillMaxWidth(),
        color = Color(0xFFF7F8FA),
        shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
      ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 18.dp)) {
          // 4x2 Grid of Services
          val rows = homeTiles.chunked(4)
          rows.forEachIndexed { rowIdx, rowItems ->
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
              rowItems.forEach { tile ->
                Box(modifier = Modifier.weight(1f)) {
                  Card(
                    onClick = {
                      if (tile.id == "send_money") {
                        showSendMenu = true
                      } else {
                        onOpenServiceAction(tile.id)
                      }
                    },
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                    modifier =
                      Modifier.fillMaxWidth()
                        .height(106.dp)
                        .testTag("home_tile_${tile.id}"),
                  ) {
                    Column(
                      modifier = Modifier.fillMaxSize().padding(horizontal = 4.dp, vertical = 10.dp),
                      horizontalAlignment = Alignment.CenterHorizontally,
                      verticalArrangement = Arrangement.Center,
                    ) {
                      HomeServiceIcon(tile.iconKey)
                      Spacer(modifier = Modifier.height(8.dp))
                      Text(
                        text = tile.label,
                        fontSize = 11.5.sp,
                        lineHeight = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = TelebirrTextPrimary,
                        textAlign = TextAlign.Center,
                        maxLines = 3,
                        overflow = TextOverflow.Ellipsis,
                      )
                    }
                  }

                  if (tile.badge != null) {
                    Box(
                      modifier =
                        Modifier.align(Alignment.TopStart)
                          .offset(y = (-6).dp)
                          .clip(RoundedCornerShape(topStart = 6.dp, topEnd = 6.dp, bottomEnd = 6.dp))
                          .background(TelebirrOrange)
                          .padding(horizontal = 6.dp, vertical = 1.dp)
                    ) {
                      Text(
                        text = tile.badge,
                        fontSize = 9.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                      )
                    }
                  }
                }
              }
            }
            if (rowIdx == 0) Spacer(modifier = Modifier.height(12.dp))
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Promo Banner Carousel (matching screenshot horizontal scroll)
          Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
          ) {
            Image(
              painter = painterResource(id = R.drawable.banner_fayda),
              contentDescription = "Link your telebirr with FAYDA",
              modifier =
                Modifier.width(326.dp)
                  .height(102.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { onOpenFaydaBanner() },
              contentScale = ContentScale.Crop,
            )
            Image(
              painter = painterResource(id = R.drawable.banner_zemen_gebeya),
              contentDescription = "Zemen Gebeya",
              modifier =
                Modifier.width(326.dp)
                  .height(102.dp)
                  .clip(RoundedCornerShape(12.dp))
                  .clickable { onOpenZemenBanner() },
              contentScale = ContentScale.Crop,
            )
          }

          Spacer(modifier = Modifier.height(18.dp))

          // Scan QR CTA Button
          Button(
            onClick = onScanQr,
            shape = RoundedCornerShape(10.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = TelebirrBlue,
                contentColor = Color.White,
              ),
            contentPadding = PaddingValues(vertical = 12.dp),
            modifier =
              Modifier.fillMaxWidth()
                .padding(horizontal = 24.dp)
                .height(48.dp)
                .testTag("home_scan_qr_button"),
          ) {
            Icon(
              imageVector = Icons.Filled.QrCodeScanner,
              contentDescription = null,
              modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.width(10.dp))
            Text(
              text = strings.scanQr,
              fontSize = 16.sp,
              fontWeight = FontWeight.SemiBold,
            )
          }

          Spacer(modifier = Modifier.height(10.dp))
        }
      }
        }
      }

      // Transaction History List Section on Main Screen
      item {
        Row(
          modifier =
            Modifier.fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = strings.transactionHistory,
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = TelebirrTextPrimary,
          )
          Text(
            text = "${uiState.transactions.size} items",
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium,
            color = TelebirrTextSecondary,
          )
        }
      }

      if (uiState.transactions.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp),
          ) {
            Column(
              modifier = Modifier.fillMaxWidth().padding(20.dp),
              horizontalAlignment = Alignment.CenterHorizontally,
            ) {
              Icon(
                imageVector = Icons.Outlined.ReceiptLong,
                contentDescription = null,
                tint = TelebirrGreen,
                modifier = Modifier.size(32.dp),
              )
              Spacer(modifier = Modifier.height(8.dp))
              Text(
                text = strings.noTransactionsYet,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TelebirrTextPrimary,
              )
              Spacer(modifier = Modifier.height(2.dp))
              Text(
                text = strings.noTransactionsDesc,
                fontSize = 12.sp,
                color = TelebirrTextSecondary,
                textAlign = TextAlign.Center,
              )
            }
          }
        }
      } else {
        itemsIndexed(
          items = uiState.transactions,
          key = { _, tx -> tx.transactionNumber },
        ) { index, tx ->
          val isCashIn = tx.transactionType == "Cash In"
          val shape =
            when {
              uiState.transactions.size == 1 -> RoundedCornerShape(12.dp)
              index == 0 -> RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
              index == uiState.transactions.lastIndex ->
                RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
              else -> RoundedCornerShape(0.dp)
            }
          Column(
            modifier =
              Modifier.fillMaxWidth()
                .padding(horizontal = 14.dp)
                .clip(shape)
                .background(Color.White)
                .clickable { onOpenTransaction(tx) }
                .testTag("home_tx_item_${tx.transactionNumber}")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RecipientAvatar(
                avatarKey =
                  when {
                    tx.recipientName.contains("Solomon", ignoreCase = true) -> "solomon"
                    tx.recipientName.equals("KENE", ignoreCase = true) -> "kene"
                    else -> "default"
                  },
                size = 40.dp,
                cornerRadius = 8.dp,
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = tx.recipientName,
                  fontSize = 14.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = TelebirrTextPrimary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
                Spacer(modifier = Modifier.height(2.dp))
                Text(
                  text = "${tx.formattedTime} • ${tx.transactionNumber}",
                  fontSize = 11.5.sp,
                  color = TelebirrTextSecondary,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis,
                )
              }
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text =
                  if (isCashIn) "+${numFmt.format(tx.amount)} ETB"
                  else "-${numFmt.format(tx.totalAmount)} ETB",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = if (isCashIn) TelebirrGreenDeep else TelebirrTextPrimary,
              )
              Spacer(modifier = Modifier.width(4.dp))
              Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = "View Receipt",
                tint = Color(0xFFBDC3C7),
                modifier = Modifier.size(18.dp),
              )
            }
            if (index < uiState.transactions.lastIndex) {
              HorizontalDivider(
                color = TelebirrDivider,
                modifier = Modifier.padding(start = 66.dp, end = 14.dp),
              )
            }
          }
        }
      }
    }

    // Floating circular location button at bottom-right matching screenshot
    Surface(
      onClick = onOpenLocationFinder,
      shape = CircleShape,
      color = Color.White,
      shadowElevation = 4.dp,
      modifier =
        Modifier.align(Alignment.BottomEnd)
          .padding(end = 14.dp, bottom = 10.dp)
          .size(44.dp)
          .testTag("home_location_fab"),
    ) {
      Box(contentAlignment = Alignment.Center) {
        Icon(
          imageVector = Icons.Filled.LocationOn,
          contentDescription = "Nearby Agents",
          tint = TelebirrGreen,
          modifier = Modifier.size(24.dp),
        )
      }
    }

    // Floating Send Money Popup Overlay ("To Individual" / "To Group") matching Screenshot_20261122-105342
    if (showSendMenu) {
      Box(
        modifier =
          Modifier.fillMaxSize()
            .background(Color.Black.copy(alpha = 0.45f))
            .clickable { showSendMenu = false }
      ) {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
          modifier =
            Modifier.align(Alignment.CenterStart)
              .padding(start = 18.dp, top = 44.dp)
              .width(210.dp)
              .shadow(10.dp, RoundedCornerShape(12.dp)),
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clickable {
                    showSendMenu = false
                    onSendIndividual()
                  }
                  .padding(horizontal = 18.dp, vertical = 18.dp)
                  .testTag("send_menu_individual"),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Outlined.AccountBalanceWallet,
                contentDescription = null,
                tint = TelebirrGreen,
                modifier = Modifier.size(26.dp),
              )
              Spacer(modifier = Modifier.width(14.dp))
              Text(
                text = strings.toIndividual,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = TelebirrTextPrimary,
              )
            }
            HorizontalDivider(color = TelebirrDivider)
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clickable {
                    showSendMenu = false
                    onSendGroup()
                  }
                  .padding(horizontal = 18.dp, vertical = 18.dp)
                  .testTag("send_menu_group"),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Outlined.Groups,
                contentDescription = null,
                tint = TelebirrGreen,
                modifier = Modifier.size(26.dp),
              )
              Spacer(modifier = Modifier.width(14.dp))
              Text(
                text = strings.toGroup,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium,
                color = TelebirrTextPrimary,
              )
            }
          }
        }
      }
    }
  }
}
