package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ConfirmationNumber
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.HelpOutline
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Translate
import androidx.compose.material.icons.filled.VerifiedUser
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TelebirrCatalog
import com.example.data.TransactionEntity
import com.example.data.WalletStateEntity
import com.example.ui.components.RecipientAvatar
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrBackground
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrDivider
import com.example.ui.theme.TelebirrGold
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary
import com.example.ui.theme.TelebirrUiStrings

private data class AccountMenuItem(
  val id: String,
  val title: String,
  val icon: ImageVector,
  val trailingText: String? = null,
)

@Composable
fun AccountScreen(
  wallet: WalletStateEntity,
  transactions: List<TransactionEntity>,
  onSelectLanguage: (String) -> Unit,
  onShowMyQr: () -> Unit,
  onOpenSearch: () -> Unit,
  onLogout: () -> Unit,
) {
  val isAmharic = LocalIsAmharic.current
  val strings = TelebirrUiStrings.forLanguage(isAmharic)
  var showLanguageDialog by remember { mutableStateOf(false) }
  var detailDialogTitle by remember { mutableStateOf<String?>(null) }
  var detailDialogBody by remember { mutableStateOf("") }
  var showTxHistoryDialog by remember { mutableStateOf(false) }

  val menuItems =
    remember(wallet.language, isAmharic) {
      listOf(
        AccountMenuItem("fayda", "Verify/Upgrade with Fayda (NID)", Icons.Filled.Badge),
        AccountMenuItem("pin", "Change PIN", Icons.Filled.Lock),
        AccountMenuItem(
          "language",
          strings.changeLanguage,
          Icons.Filled.Translate,
          trailingText = wallet.language.substringBefore(" "),
        ),
        AccountMenuItem("security", "Security Question", Icons.Filled.Quiz),
        AccountMenuItem("biometric", "Biometric Authentication", Icons.Filled.Fingerprint),
        AccountMenuItem("faq", "FAQ", Icons.Filled.HelpOutline),
        AccountMenuItem("feedback", "Feedback", Icons.Outlined.ChatBubbleOutline),
        AccountMenuItem("contact", "Contact Us", Icons.Filled.SupportAgent),
        AccountMenuItem("about", "About", Icons.Filled.Info),
        AccountMenuItem("share", "Share", Icons.Filled.Share),
        AccountMenuItem("coupon", "My Coupon", Icons.Filled.ConfirmationNumber),
        AccountMenuItem("history", "Bill Share History", Icons.Filled.Receipt),
        AccountMenuItem("verify", "Verify Payment", Icons.Filled.VerifiedUser),
        AccountMenuItem("wifi", "Access on WI-FI", Icons.Filled.Wifi),
      )
    }

  Column(modifier = Modifier.fillMaxSize().background(TelebirrBackground)) {
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(TelebirrGreen)
          .statusBarsPadding()
          .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Spacer(modifier = Modifier.size(40.dp))
      Text(
        text = strings.account,
        fontSize = 19.sp,
        fontWeight = FontWeight.Medium,
        color = Color.White,
        textAlign = TextAlign.Center,
        modifier = Modifier.weight(1f),
      )
      IconButton(onClick = onOpenSearch, modifier = Modifier.size(40.dp)) {
        Icon(
          imageVector = Icons.Filled.Search,
          contentDescription = "Search Account",
          tint = Color.White,
        )
      }
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item { Spacer(modifier = Modifier.height(6.dp)) }

      // Profile Card
      item {
        Card(
          onClick = onShowMyQr,
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth().padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            RecipientAvatar(avatarKey = "fikiru", size = 58.dp, cornerRadius = 10.dp)
            Spacer(modifier = Modifier.width(14.dp))
            Column(modifier = Modifier.weight(1f)) {
              Text(
                text = wallet.userName,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = TelebirrTextPrimary,
              )
              Spacer(modifier = Modifier.height(6.dp))
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                  modifier =
                    Modifier.clip(RoundedCornerShape(4.dp))
                      .background(TelebirrGold)
                      .padding(horizontal = 8.dp, vertical = 2.dp)
                ) {
                  Text(
                    text = wallet.level,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                  )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                  text = "+251${wallet.phoneNumber}",
                  fontSize = 13.sp,
                  color = TelebirrTextSecondary,
                )
              }
            }
            Icon(
              imageVector = Icons.Filled.QrCode2,
              contentDescription = "My QR",
              tint = TelebirrGreen,
              modifier = Modifier.size(28.dp),
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
              imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
              contentDescription = null,
              tint = Color(0xFFBDC3C7),
            )
          }
        }
      }

      // Settings Menu List Card
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            menuItems.forEachIndexed { index, item ->
              Row(
                modifier =
                  Modifier.fillMaxWidth()
                    .clickable {
                      when (item.id) {
                        "language" -> showLanguageDialog = true
                        "history", "verify" -> showTxHistoryDialog = true
                        else -> {
                          detailDialogTitle = item.title
                          detailDialogBody =
                            when (item.id) {
                              "fayda" ->
                                "Your telebirr Level 3 wallet is ready to link with your 12-digit Fayda National Digital ID (FIN)."
                              "pin" ->
                                "For security, PIN changes require SMS OTP verification sent to +251${wallet.phoneNumber}."
                              "biometric" ->
                                "Fingerprint & face authentication is active for instant telebirr SuperApp sign-in and transfer approval."
                              "contact" ->
                                "Ethio telecom Customer Care: Dial 127 (toll-free) or email support@ethiotelecom.et."
                              "about" ->
                                "telebirr SuperApp Version 1.3.3\n@2026 Ethio telecom. All rights reserved."
                              else ->
                                "${item.title} is available for your active +251${wallet.phoneNumber} telebirr account."
                            }
                        }
                      }
                    }
                    .padding(horizontal = 16.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = item.icon,
                  contentDescription = null,
                  tint = if (item.id == "fayda" || item.id == "coupon") TelebirrBlue else TelebirrGreen,
                  modifier = Modifier.size(24.dp),
                )
                Spacer(modifier = Modifier.width(14.dp))
                Text(
                  text = item.title,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Normal,
                  color = TelebirrTextPrimary,
                  modifier = Modifier.weight(1f),
                )
                if (item.trailingText != null) {
                  Text(
                    text = item.trailingText,
                    fontSize = 13.sp,
                    color = TelebirrTextSecondary,
                    modifier = Modifier.padding(end = 4.dp),
                  )
                }
                Icon(
                  imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                  contentDescription = null,
                  tint = Color(0xFFBDC3C7),
                  modifier = Modifier.size(20.dp),
                )
              }
              if (index < menuItems.lastIndex) {
                HorizontalDivider(
                  color = TelebirrDivider,
                  modifier = Modifier.padding(horizontal = 16.dp),
                )
              }
            }
          }
        }
      }

      // Blue Logout Button matching screenshot
      item {
        Spacer(modifier = Modifier.height(4.dp))
        Button(
          onClick = onLogout,
          shape = RoundedCornerShape(10.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = TelebirrBlue,
              contentColor = Color.White,
            ),
          modifier =
            Modifier.fillMaxWidth()
              .height(48.dp)
              .testTag("account_logout_button"),
        ) {
          Text(
            text = strings.logout,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
          )
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }

  if (showLanguageDialog) {
    AlertDialog(
      onDismissRequest = { showLanguageDialog = false },
      title = { Text(strings.changeLanguage, fontWeight = FontWeight.Bold) },
      text = {
        Column {
          TelebirrCatalog.languages.forEach { lang ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable {
                    onSelectLanguage(lang)
                    showLanguageDialog = false
                  }
                  .padding(vertical = 12.dp, horizontal = 8.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(lang, fontSize = 15.sp, color = TelebirrTextPrimary)
              if (wallet.language == lang) {
                Icon(Icons.Filled.CheckCircle, null, tint = TelebirrGreen)
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showLanguageDialog = false }) {
          Text("Close", color = TelebirrBlue)
        }
      },
    )
  }

  if (showTxHistoryDialog) {
    AlertDialog(
      onDismissRequest = { showTxHistoryDialog = false },
      title = { Text("Recent Transactions", fontWeight = FontWeight.Bold) },
      text = {
        if (transactions.isEmpty()) {
          Text("No completed transactions yet in this session.")
        } else {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            transactions.take(6).forEach { tx ->
              Column(modifier = Modifier.fillMaxWidth()) {
                Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                  Text(tx.recipientName, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
                  Text(
                    "-${String.format("%.2f", tx.totalAmount)} ETB",
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    color = TelebirrTextPrimary,
                  )
                }
                Text(
                  "Number: +${tx.recipientPhone}",
                  fontSize = 12.sp,
                  color = TelebirrTextSecondary,
                )
                Text(
                  "Txn: ${tx.transactionNumber} • ${tx.formattedTime}",
                  fontSize = 12.sp,
                  color = TelebirrTextSecondary,
                )
              }
              HorizontalDivider(color = TelebirrDivider)
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showTxHistoryDialog = false }) {
          Text("Done", color = TelebirrBlue)
        }
      },
    )
  }

  if (detailDialogTitle != null) {
    AlertDialog(
      onDismissRequest = { detailDialogTitle = null },
      title = { Text(detailDialogTitle ?: "", fontWeight = FontWeight.Bold) },
      text = { Text(detailDialogBody, color = TelebirrTextSecondary) },
      confirmButton = {
        TextButton(onClick = { detailDialogTitle = null }) {
          Text("OK", color = TelebirrBlue)
        }
      },
    )
  }
}
