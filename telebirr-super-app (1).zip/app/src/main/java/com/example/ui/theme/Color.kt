package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val TelebirrGreen = Color(0xFF8CC63F)
val TelebirrGreenDeep = Color(0xFF72B02D)
val TelebirrGreenLight = Color(0xFFA3D858)
val TelebirrGreenSoft = Color(0xFFEAF5DC)
val TelebirrGreenDisabled = Color(0xFFD6E8C1)

val TelebirrBlue = Color(0xFF0072BC)
val TelebirrBlueLight = Color(0xFFBCE0F5)
val TelebirrBlueSoft = Color(0xFFE6F3FB)

val TelebirrGold = Color(0xFFF5BC1A)
val TelebirrOrange = Color(0xFFF5A623)
val TelebirrOrangeDeep = Color(0xFFE8931E)

val TelebirrBackground = Color(0xFFF6F7F9)
val TelebirrLoginBg = Color(0xFFFCFDFA)
val TelebirrSurface = Color(0xFFFFFFFF)
val TelebirrSurfaceMuted = Color(0xFFF2F4F7)

val TelebirrTextPrimary = Color(0xFF1D2129)
val TelebirrTextSecondary = Color(0xFF6B7280)
val TelebirrTextMuted = Color(0xFF9CA3AF)
val TelebirrDivider = Color(0xFFECEEF2)
val TelebirrBorder = Color(0xFFE5E7EB)
val TelebirrError = Color(0xFFD93025)
