package com.example.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.RecipientEntity
import com.example.data.SmsNotificationItem
import com.example.data.TelebirrRepository
import com.example.data.TransactionEntity
import com.example.data.WalletStateEntity
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class SendMoneyDraft(
  val recipientName: String = "",
  val recipientPhone: String = "",
  val avatarKey: String = "default",
  val amountInput: String = "",
  val notes: String = "",
  val transactionType: String = "Transfer Money",
)

data class TelebirrUiState(
  val wallet: WalletStateEntity = WalletStateEntity(),
  val isWalletLoaded: Boolean = false,
  val recentRecipients: List<RecipientEntity> = emptyList(),
  val transactions: List<TransactionEntity> = emptyList(),
  val showBalance: Boolean = true,
  val showEndekise: Boolean = true,
  val showReward: Boolean = true,
  val loginPhoneInput: String = "961041860",
  val sendDraft: SendMoneyDraft = SendMoneyDraft(),
  val activeReceipt: TransactionEntity? = null,
  val smsNotifications: List<SmsNotificationItem> = defaultNotifications(),
  val activeSmsBanner: SmsNotificationItem? = null,
  val errorMessage: String? = null,
  val infoBannerMessage: String? = null,
  val isProcessing: Boolean = false,
) {
  companion object {
    fun defaultNotifications(): List<SmsNotificationItem> =
      listOf(
        SmsNotificationItem(
          id = "n1",
          title = "Telebirr – Ethiotelecom",
          body = "Welcome to telebirr SuperApp 1.3.3! Link your telebirr account with Fayda Digital ID for higher limits.",
          timeLabel = "10:53 am",
          isUnread = true,
        )
      )
  }
}

private data class TransientUiState(
  val showBalance: Boolean = true,
  val showEndekise: Boolean = true,
  val showReward: Boolean = true,
  val loginPhoneInput: String = "961041860",
  val sendDraft: SendMoneyDraft = SendMoneyDraft(),
  val activeReceipt: TransactionEntity? = null,
  val smsNotifications: List<SmsNotificationItem> = TelebirrUiState.defaultNotifications(),
  val activeSmsBanner: SmsNotificationItem? = null,
  val errorMessage: String? = null,
  val infoBannerMessage: String? = null,
  val isProcessing: Boolean = false,
)

class TelebirrViewModel(private val repository: TelebirrRepository) : ViewModel() {

  private val transientState = MutableStateFlow(TransientUiState())

  val uiState: StateFlow<TelebirrUiState> =
    combine(
        repository.walletState,
        repository.recentRecipients,
        repository.transactions,
        transientState,
      ) { wallet, recipients, txs, transient ->
        TelebirrUiState(
          wallet = wallet ?: WalletStateEntity(),
          isWalletLoaded = wallet != null,
          recentRecipients = recipients,
          transactions = txs,
          showBalance = transient.showBalance,
          showEndekise = transient.showEndekise,
          showReward = transient.showReward,
          loginPhoneInput = transient.loginPhoneInput,
          sendDraft = transient.sendDraft,
          activeReceipt = transient.activeReceipt,
          smsNotifications = transient.smsNotifications,
          activeSmsBanner = transient.activeSmsBanner,
          errorMessage = transient.errorMessage,
          infoBannerMessage = transient.infoBannerMessage,
          isProcessing = transient.isProcessing,
        )
      }
      .stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5_000),
        initialValue = TelebirrUiState(),
      )

  init {
    viewModelScope.launch { repository.ensureSeeded() }
  }

  fun updateLoginPhone(value: String) {
    val digitsOnly = value.filter { it.isDigit() }.take(10)
    transientState.update { it.copy(loginPhoneInput = digitsOnly, errorMessage = null) }
  }

  fun login(onSuccess: () -> Unit) {
    val digits = transientState.value.loginPhoneInput.filter { it.isDigit() }
    if (digits.length < 9) {
      transientState.update { it.copy(errorMessage = "Please enter a valid +251 mobile number") }
      return
    }
    viewModelScope.launch {
      repository.login(digits)
      transientState.update { it.copy(errorMessage = null) }
      onSuccess()
    }
  }

  fun logout(onLoggedOut: () -> Unit) {
    viewModelScope.launch {
      repository.logout()
      onLoggedOut()
    }
  }

  fun toggleBalanceVisibility() {
    transientState.update { it.copy(showBalance = !it.showBalance) }
  }

  fun toggleEndekiseVisibility() {
    transientState.update { it.copy(showEndekise = !it.showEndekise) }
  }

  fun toggleRewardVisibility() {
    transientState.update { it.copy(showReward = !it.showReward) }
  }

  fun selectLanguage(language: String) {
    viewModelScope.launch {
      repository.updateLanguage(language)
      transientState.update { it.copy(infoBannerMessage = "Language updated to $language") }
    }
  }

  fun startSendMoneyFlow(
    recipientName: String = "",
    recipientPhone: String = "",
    avatarKey: String = "default",
    transactionType: String = "Transfer Money",
  ) {
    transientState.update {
      it.copy(
        sendDraft =
          SendMoneyDraft(
            recipientName = recipientName,
            recipientPhone = recipientPhone,
            avatarKey = avatarKey,
            amountInput = "",
            notes = "",
            transactionType = transactionType,
          ),
        errorMessage = null,
      )
    }
  }

  fun updateRecipientDetails(name: String, phone: String) {
    val cleanedPhone = phone.filter { it.isDigit() }.take(12)
    transientState.update {
      it.copy(
        sendDraft = it.sendDraft.copy(recipientName = name, recipientPhone = cleanedPhone),
        errorMessage = null,
      )
    }
  }

  fun selectRecentRecipient(recipient: RecipientEntity) {
    val localPhone =
      if (recipient.phoneNumber.startsWith("251") && recipient.phoneNumber.length > 3) {
        recipient.phoneNumber.drop(3)
      } else {
        recipient.phoneNumber
      }
    transientState.update {
      it.copy(
        sendDraft =
          it.sendDraft.copy(
            recipientName = recipient.name,
            recipientPhone = localPhone,
            avatarKey = recipient.avatarKey,
          ),
        errorMessage = null,
      )
    }
  }

  fun clearRecentRecipients() {
    viewModelScope.launch {
      repository.clearRecentRecipients()
      transientState.update { it.copy(infoBannerMessage = "Recent recipients cleared") }
    }
  }

  fun onKeypadPress(key: String) {
    transientState.update { state ->
      val current = state.sendDraft.amountInput
      val updated =
        when (key) {
          "BACKSPACE" -> if (current.isNotEmpty()) current.dropLast(1) else ""
          "." -> {
            when {
              current.contains('.') -> current
              current.isEmpty() -> "0."
              else -> "$current."
            }
          }
          else -> {
            val dotIdx = current.indexOf('.')
            if (dotIdx >= 0 && current.length - dotIdx > 2) {
              current
            } else if (current == "0" && key != ".") {
              key
            } else if (current.length >= 9) {
              current
            } else {
              current + key
            }
          }
        }
      state.copy(sendDraft = state.sendDraft.copy(amountInput = updated), errorMessage = null)
    }
  }

  fun updateNotes(notes: String) {
    transientState.update {
      it.copy(sendDraft = it.sendDraft.copy(notes = notes.take(80)))
    }
  }

  fun calculateFee(amount: Double): Double = repository.calculateServiceFee(amount)

  fun confirmSendMoney(onSuccess: () -> Unit) {
    val currentDraft = transientState.value.sendDraft
    val amount = currentDraft.amountInput.toDoubleOrNull() ?: 0.0
    if (amount <= 0.0) {
      transientState.update { it.copy(errorMessage = "Please enter an amount greater than 0") }
      return
    }
    if (currentDraft.recipientName.trim().isEmpty()) {
      transientState.update { it.copy(errorMessage = "Please enter the recipient's name") }
      return
    }
    transientState.update { it.copy(isProcessing = true, errorMessage = null) }
    viewModelScope.launch {
      val result =
        repository.sendMoney(
          recipientName = currentDraft.recipientName,
          recipientPhone = currentDraft.recipientPhone,
          amount = amount,
          notes = currentDraft.notes,
          transactionType = currentDraft.transactionType,
          avatarKey = currentDraft.avatarKey,
        )
      result
        .onSuccess { tx ->
          val dateTimeFmt = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.US)
          val timeFmt = SimpleDateFormat("hh:mm a", Locale.US)
          val now = Date(tx.timestampMillis)
          val masked = TelebirrRepository.maskPhone(tx.recipientPhone)
          val baseServiceFee = kotlin.math.round((tx.serviceFee / 1.15) * 100.0) / 100.0
          val vatOnFee = kotlin.math.round((tx.serviceFee - baseServiceFee) * 100.0) / 100.0
          val newBalance =
            kotlin.math.round((uiState.value.wallet.balance - tx.totalAmount).coerceAtLeast(0.0) * 100.0) /
              100.0
          val sms =
            SmsNotificationItem(
              id = tx.transactionNumber,
              title = "Telebirr – Ethiotelecom",
              body =
                "Dear ${uiState.value.wallet.userName}\n" +
                  "You have transferred ETB ${String.format(Locale.US, "%.2f", tx.amount)} to " +
                  "${tx.recipientName} ($masked) on ${dateTimeFmt.format(now)}.\n" +
                  "Your transaction number is ${tx.transactionNumber}. The service fee is ETB " +
                  "${String.format(Locale.US, "%.2f", baseServiceFee)} and 15% VAT on the service fee is ETB " +
                  "${String.format(Locale.US, "%.2f", vatOnFee)}.\n" +
                  "Your current E-Money Account balance is ETB ${String.format(Locale.US, "%,.2f", newBalance)}. " +
                  "To download your payment information please visit telebirr.",
              timeLabel = timeFmt.format(now).lowercase(Locale.US),
              isUnread = true,
            )
          transientState.update {
            it.copy(
              isProcessing = false,
              activeReceipt = tx,
              smsNotifications = listOf(sms) + it.smsNotifications,
              activeSmsBanner = sms,
            )
          }
          onSuccess()
        }
        .onFailure { err ->
          transientState.update {
            it.copy(
              isProcessing = false,
              errorMessage = err.message ?: "Unable to complete transaction",
            )
          }
        }
    }
  }

  fun performCashIn(amountText: String, onDone: () -> Unit) {
    val amount = amountText.toDoubleOrNull() ?: 0.0
    if (amount <= 0.0) {
      transientState.update { it.copy(errorMessage = "Enter a valid Cash In amount") }
      return
    }
    viewModelScope.launch {
      repository
        .cashIn(amount)
        .onSuccess { tx ->
          transientState.update {
            it.copy(
              infoBannerMessage =
                "Added ${String.format(Locale.US, "%.2f", tx.amount)} ETB to your wallet",
              errorMessage = null,
            )
          }
          onDone()
        }
        .onFailure { err ->
          transientState.update { it.copy(errorMessage = err.message) }
        }
    }
  }

  fun dismissSmsBanner() {
    transientState.update { state ->
      val currentId = state.activeSmsBanner?.id
      state.copy(
        activeSmsBanner = null,
        smsNotifications =
          state.smsNotifications.map { n ->
            if (n.id == currentId) n.copy(isUnread = false) else n
          },
      )
    }
  }

  fun markAllNotificationsRead() {
    transientState.update { state ->
      state.copy(smsNotifications = state.smsNotifications.map { it.copy(isUnread = false) })
    }
  }

  fun clearError() {
    transientState.update { it.copy(errorMessage = null) }
  }

  fun clearInfoBanner() {
    transientState.update { it.copy(infoBannerMessage = null) }
  }

  fun openTransactionReceipt(transaction: TransactionEntity) {
    transientState.update { it.copy(activeReceipt = transaction) }
  }

  fun deleteTransaction(transactionNumber: String) {
    viewModelScope.launch {
      repository.deleteTransaction(transactionNumber)
      transientState.update { it.copy(infoBannerMessage = "Transaction removed from history") }
    }
  }

  fun showInfoMessage(message: String) {
    transientState.update { it.copy(infoBannerMessage = message) }
  }
}

class TelebirrViewModelFactory(private val repository: TelebirrRepository) :
  ViewModelProvider.Factory {
  @Suppress("UNCHECKED_CAST")
  override fun <T : ViewModel> create(modelClass: Class<T>): T {
    if (modelClass.isAssignableFrom(TelebirrViewModel::class.java)) {
      return TelebirrViewModel(repository) as T
    }
    throw IllegalArgumentException("Unknown ViewModel class: ${modelClass.name}")
  }
}
