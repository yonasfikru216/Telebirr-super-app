package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Contacts
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material.icons.outlined.QrCodeScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.RecipientEntity
import com.example.ui.components.RecipientAvatar
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrBackground
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrBlueLight
import com.example.ui.theme.TelebirrDivider
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextMuted
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary
import com.example.ui.theme.TelebirrUiStrings

@Composable
fun SendMoneyRecipientScreen(
  recipientName: String,
  recipientPhone: String,
  recentRecipients: List<RecipientEntity>,
  onBack: () -> Unit,
  onDetailsChange: (name: String, phone: String) -> Unit,
  onNext: () -> Unit,
  onSelectRecent: (RecipientEntity) -> Unit,
  onClearRecent: () -> Unit,
  onScanQrClick: () -> Unit,
) {
  val strings = TelebirrUiStrings.forLanguage(LocalIsAmharic.current)
  var showClearConfirm by remember { mutableStateOf(false) }
  var showContactHint by remember { mutableStateOf(false) }
  val pagerState = rememberPagerState(pageCount = { 2 })

  val isFormValid =
    recipientPhone.filter { it.isDigit() }.length >= 9 && recipientName.trim().isNotEmpty()

  Column(
    modifier =
      Modifier.fillMaxSize()
        .background(TelebirrBackground)
        .statusBarsPadding()
        .navigationBarsPadding()
  ) {
    // Top App Bar
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(Color.White)
          .padding(horizontal = 6.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack, modifier = Modifier.testTag("send_recipient_back")) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = TelebirrTextPrimary,
        )
      }
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = strings.sendMoneyToIndividual,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = TelebirrTextPrimary,
      )
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item {
        Spacer(modifier = Modifier.height(8.dp))
        HorizontalPager(
          state = pagerState,
          modifier = Modifier.fillMaxWidth(),
        ) { page ->
          val resId =
            if (page == 0) R.drawable.banner_fayda else R.drawable.banner_zemen_gebeya
          Image(
            painter = painterResource(id = resId),
            contentDescription = "Telebirr promo banner",
            modifier =
              Modifier.fillMaxWidth()
                .height(106.dp)
                .clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop,
          )
        }
        Spacer(modifier = Modifier.height(8.dp))
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.Center,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          repeat(2) { index ->
            val active = pagerState.currentPage == index
            Box(
              modifier =
                Modifier.padding(horizontal = 3.dp)
                  .size(7.dp)
                  .clip(CircleShape)
                  .background(if (active) TelebirrGreen else Color.Transparent)
                  .border(1.dp, TelebirrGreen, CircleShape)
            )
          }
        }
      }

      // Main Input Card (Mobile Number + Recipient Name + Next Button)
      item {
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Text(
              text = strings.enterMobileNumber,
              fontSize = 15.sp,
              fontWeight = FontWeight.Medium,
              color = TelebirrTextPrimary,
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .height(50.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .border(1.5.dp, TelebirrGreen, RoundedCornerShape(8.dp))
                  .background(Color.White)
                  .padding(horizontal = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = "+251",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium,
                color = TelebirrTextPrimary,
              )
              Spacer(modifier = Modifier.width(10.dp))
              BasicTextField(
                value = recipientPhone,
                onValueChange = { onDetailsChange(recipientName, it) },
                singleLine = true,
                textStyle = TextStyle(fontSize = 16.sp, color = TelebirrTextPrimary),
                cursorBrush = SolidColor(TelebirrGreen),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                modifier = Modifier.weight(1f).testTag("recipient_phone_input"),
                decorationBox = { inner ->
                  if (recipientPhone.isEmpty()) {
                    Text(
                      text = "9XXXXXXXX",
                      fontSize = 15.sp,
                      color = TelebirrTextMuted,
                    )
                  }
                  inner()
                },
              )
              IconButton(
                onClick = onScanQrClick,
                modifier = Modifier.size(36.dp),
              ) {
                Icon(
                  imageVector = Icons.Outlined.QrCodeScanner,
                  contentDescription = "Scan Recipient QR",
                  tint = TelebirrGreen,
                  modifier = Modifier.size(22.dp),
                )
              }
              IconButton(
                onClick = { showContactHint = true },
                modifier = Modifier.size(36.dp),
              ) {
                Icon(
                  imageVector = Icons.Outlined.Contacts,
                  contentDescription = "Pick from Recent Contacts",
                  tint = TelebirrGreen,
                  modifier = Modifier.size(22.dp),
                )
              }
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
              text = strings.recipientTxName,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = TelebirrTextPrimary,
            )

            Spacer(modifier = Modifier.height(8.dp))

            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .height(48.dp)
                  .clip(RoundedCornerShape(8.dp))
                  .border(1.2.dp, TelebirrGreen.copy(alpha = 0.75f), RoundedCornerShape(8.dp))
                  .background(Color.White)
                  .padding(horizontal = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Outlined.PersonOutline,
                contentDescription = null,
                tint = TelebirrGreen,
                modifier = Modifier.size(20.dp),
              )
              Spacer(modifier = Modifier.width(10.dp))
              BasicTextField(
                value = recipientName,
                onValueChange = { onDetailsChange(it, recipientPhone) },
                singleLine = true,
                textStyle = TextStyle(fontSize = 15.sp, color = TelebirrTextPrimary),
                cursorBrush = SolidColor(TelebirrGreen),
                keyboardOptions =
                  KeyboardOptions(capitalization = KeyboardCapitalization.Words),
                modifier = Modifier.weight(1f).testTag("recipient_name_input"),
                decorationBox = { inner ->
                  if (recipientName.isEmpty()) {
                    Text(
                      text = strings.enterRecipientNameHint,
                      fontSize = 14.sp,
                      color = TelebirrTextMuted,
                    )
                  }
                  inner()
                },
              )
            }

            Spacer(modifier = Modifier.height(18.dp))

            Button(
              onClick = onNext,
              enabled = isFormValid,
              shape = RoundedCornerShape(10.dp),
              colors =
                ButtonDefaults.buttonColors(
                  containerColor = TelebirrBlue,
                  contentColor = Color.White,
                  disabledContainerColor = TelebirrBlueLight,
                  disabledContentColor = Color.White,
                ),
              modifier =
                Modifier.fillMaxWidth()
                  .height(48.dp)
                  .testTag("recipient_next_button"),
            ) {
              Text(
                text = strings.next,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
              )
            }
          }
        }
      }

      // Recent Contacts Header
      item {
        Row(
          modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = strings.recent,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium,
            color = TelebirrTextPrimary,
          )
          if (recentRecipients.isNotEmpty()) {
            IconButton(
              onClick = { showClearConfirm = true },
              modifier = Modifier.size(36.dp).testTag("clear_recent_button"),
            ) {
              Icon(
                imageVector = Icons.Outlined.DeleteOutline,
                contentDescription = "Clear Recent Recipients",
                tint = TelebirrTextMuted,
                modifier = Modifier.size(20.dp),
              )
            }
          }
        }
      }

      // Recent Recipients List Card
      if (recentRecipients.isEmpty()) {
        item {
          Card(
            shape = RoundedCornerShape(12.dp),
            colors = CardDefaults.cardColors(containerColor = Color.White),
            modifier = Modifier.fillMaxWidth(),
          ) {
            Text(
              text = "No recent recipients yet. Enter a mobile number and name above to send money.",
              fontSize = 13.sp,
              color = TelebirrTextSecondary,
              modifier = Modifier.padding(18.dp),
            )
          }
        }
      } else {
        itemsIndexed(recentRecipients, key = { _, item -> item.phoneNumber }) { index, recipient ->
          val shape =
            when {
              recentRecipients.size == 1 -> RoundedCornerShape(12.dp)
              index == 0 -> RoundedCornerShape(topStart = 12.dp, topEnd = 12.dp)
              index == recentRecipients.lastIndex ->
                RoundedCornerShape(bottomStart = 12.dp, bottomEnd = 12.dp)
              else -> RoundedCornerShape(0.dp)
            }
          Column(
            modifier =
              Modifier.fillMaxWidth()
                .clip(shape)
                .background(Color.White)
                .clickable { onSelectRecent(recipient) }
                .testTag("recent_recipient_${recipient.name}")
          ) {
            Row(
              modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RecipientAvatar(avatarKey = recipient.avatarKey, size = 40.dp, cornerRadius = 8.dp)
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = recipient.name,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Medium,
                  color = TelebirrTextPrimary,
                )
                Text(
                  text = "+${recipient.phoneNumber}",
                  fontSize = 12.sp,
                  color = TelebirrTextSecondary,
                )
              }
              Icon(
                imageVector = Icons.AutoMirrored.Filled.KeyboardArrowRight,
                contentDescription = null,
                tint = Color(0xFFBDC3C7),
                modifier = Modifier.size(20.dp),
              )
            }
            if (index < recentRecipients.lastIndex) {
              HorizontalDivider(
                color = TelebirrDivider,
                modifier = Modifier.padding(start = 66.dp, end = 14.dp),
              )
            }
          }
        }
      }

      item { Spacer(modifier = Modifier.height(20.dp)) }
    }
  }

  if (showClearConfirm) {
    AlertDialog(
      onDismissRequest = { showClearConfirm = false },
      title = { Text("Clear Recent Recipients", fontWeight = FontWeight.Bold) },
      text = { Text("Remove all saved recipients from your recent list?") },
      confirmButton = {
        TextButton(
          onClick = {
            showClearConfirm = false
            onClearRecent()
          }
        ) {
          Text("Clear", color = TelebirrBlue, fontWeight = FontWeight.SemiBold)
        }
      },
      dismissButton = {
        TextButton(onClick = { showClearConfirm = false }) { Text("Cancel") }
      },
    )
  }

  if (showContactHint) {
    AlertDialog(
      onDismissRequest = { showContactHint = false },
      title = { Text("Select a Contact", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
          Text("Choose from saved Telebirr contacts or enter any number manually:", fontSize = 13.sp, color = TelebirrTextSecondary)
          recentRecipients.take(5).forEach { contact ->
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .clip(RoundedCornerShape(8.dp))
                  .clickable {
                    showContactHint = false
                    onSelectRecent(contact)
                  }
                  .padding(vertical = 8.dp, horizontal = 6.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              RecipientAvatar(avatarKey = contact.avatarKey, size = 32.dp)
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(contact.name, fontWeight = FontWeight.Medium, fontSize = 14.sp)
                Text("+${contact.phoneNumber}", fontSize = 12.sp, color = TelebirrTextSecondary)
              }
            }
          }
        }
      },
      confirmButton = {
        TextButton(onClick = { showContactHint = false }) {
          Text("Close", color = TelebirrBlue)
        }
      },
    )
  }
}
