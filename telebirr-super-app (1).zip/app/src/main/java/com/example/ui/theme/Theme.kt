package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val TelebirrColorScheme =
  lightColorScheme(
    primary = TelebirrGreen,
    onPrimary = Color.White,
    primaryContainer = TelebirrGreenSoft,
    onPrimaryContainer = TelebirrTextPrimary,
    secondary = TelebirrBlue,
    onSecondary = Color.White,
    secondaryContainer = TelebirrBlueSoft,
    onSecondaryContainer = TelebirrBlue,
    tertiary = TelebirrGold,
    onTertiary = Color.White,
    background = TelebirrBackground,
    onBackground = TelebirrTextPrimary,
    surface = TelebirrSurface,
    onSurface = TelebirrTextPrimary,
    surfaceVariant = TelebirrSurfaceMuted,
    onSurfaceVariant = TelebirrTextSecondary,
    outline = TelebirrBorder,
    outlineVariant = TelebirrDivider,
    error = TelebirrError,
    onError = Color.White,
  )

@Composable
fun TelebirrTheme(content: @Composable () -> Unit) {
  MaterialTheme(
    colorScheme = TelebirrColorScheme,
    typography = TelebirrTypography,
    content = content,
  )
}
