package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.MiniAppItem
import com.example.data.TelebirrCatalog
import com.example.ui.components.MiniAppBadge
import com.example.ui.theme.TelebirrBackground
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextPrimary

@Composable
fun AppsScreen(
  onOpenMiniApp: (MiniAppItem) -> Unit,
) {
  var showSearch by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }

  val filteredApps =
    remember(searchQuery) {
      if (searchQuery.isBlank()) TelebirrCatalog.miniApps
      else {
        val q = searchQuery.trim().lowercase()
        TelebirrCatalog.miniApps.filter {
          it.title.lowercase().contains(q) || it.category.lowercase().contains(q)
        }
      }
    }

  val rows = remember(filteredApps) { filteredApps.chunked(3) }

  Column(modifier = Modifier.fillMaxSize().background(TelebirrBackground)) {
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(TelebirrGreen)
          .statusBarsPadding()
          .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Spacer(modifier = Modifier.size(40.dp))
      Text(
        text = "Apps",
        fontSize = 19.sp,
        fontWeight = FontWeight.Medium,
        color = Color.White,
        textAlign = TextAlign.Center,
        modifier = Modifier.weight(1f),
      )
      IconButton(
        onClick = {
          showSearch = !showSearch
          if (!showSearch) searchQuery = ""
        },
        modifier = Modifier.size(40.dp).testTag("apps_search_toggle"),
      ) {
        Icon(
          imageVector = if (showSearch) Icons.Filled.Close else Icons.Filled.Search,
          contentDescription = "Search Mini Apps",
          tint = Color.White,
        )
      }
    }

    AnimatedVisibility(visible = showSearch) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search mini-apps (e.g., RIDE, Airlines, DStv)...") },
        singleLine = true,
        shape = RoundedCornerShape(10.dp),
        modifier =
          Modifier.fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 14.dp, vertical = 10.dp),
      )
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item { Spacer(modifier = Modifier.height(6.dp)) }

      items(rows) { rowItems ->
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          rowItems.forEach { app ->
            Card(
              onClick = { onOpenMiniApp(app) },
              shape = RoundedCornerShape(12.dp),
              colors = CardDefaults.cardColors(containerColor = Color.White),
              elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
              modifier =
                Modifier.weight(1f)
                  .height(114.dp)
                  .testTag("mini_app_${app.id}"),
            ) {
              Column(
                modifier = Modifier.fillMaxSize().padding(horizontal = 6.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
              ) {
                MiniAppBadge(app.iconKey)
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                  text = app.title,
                  fontSize = 12.sp,
                  lineHeight = 14.sp,
                  color = TelebirrTextPrimary,
                  textAlign = TextAlign.Center,
                  maxLines = 3,
                  overflow = TextOverflow.Ellipsis,
                )
              }
            }
          }
          repeat(3 - rowItems.size) {
            Spacer(modifier = Modifier.weight(1f))
          }
        }
      }

      item {
        Spacer(modifier = Modifier.height(6.dp))
        Row(
          modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
          horizontalArrangement = Arrangement.spacedBy(12.dp),
        ) {
          Image(
            painter = painterResource(id = R.drawable.banner_fayda),
            contentDescription = "Fayda Banner",
            modifier = Modifier.width(316.dp).height(96.dp).clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop,
          )
          Image(
            painter = painterResource(id = R.drawable.banner_zemen_gebeya),
            contentDescription = "Zemen Gebeya Banner",
            modifier = Modifier.width(316.dp).height(96.dp).clip(RoundedCornerShape(12.dp)),
            contentScale = ContentScale.Crop,
          )
        }
        Spacer(modifier = Modifier.height(16.dp))
      }
    }
  }
}
