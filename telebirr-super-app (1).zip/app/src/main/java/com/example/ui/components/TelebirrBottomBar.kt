package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.CreditCard
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.outlined.AccountCircle
import androidx.compose.material.icons.outlined.Apps
import androidx.compose.material.icons.outlined.ChatBubbleOutline
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrUiStrings

enum class MainTab(
  val route: String,
  val label: String,
  val selectedIcon: ImageVector,
  val unselectedIcon: ImageVector,
) {
  HOME("home", "Home", Icons.Filled.Home, Icons.Outlined.Home),
  PAYMENT("payment", "Payment", Icons.Filled.CreditCard, Icons.Outlined.CreditCard),
  APPS("apps", "Apps", Icons.Filled.Apps, Icons.Outlined.Apps),
  ENGAGE("engage", "Engage", Icons.Filled.ChatBubbleOutline, Icons.Outlined.ChatBubbleOutline),
  ACCOUNT("account", "Account", Icons.Filled.AccountCircle, Icons.Outlined.AccountCircle),
}

@Composable
fun TelebirrBottomBar(
  currentTab: MainTab,
  onSelectTab: (MainTab) -> Unit,
  modifier: Modifier = Modifier,
) {
  val strings = TelebirrUiStrings.forLanguage(LocalIsAmharic.current)
  Box(
    modifier =
      modifier
        .fillMaxWidth()
        .background(TelebirrGreen)
        .navigationBarsPadding()
  ) {
    Row(
      modifier = Modifier.fillMaxWidth().height(60.dp),
      horizontalArrangement = Arrangement.SpaceEvenly,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      MainTab.entries.forEach { tab ->
        val selected = tab == currentTab
        val tabLabel =
          when (tab) {
            MainTab.HOME -> strings.tabHome
            MainTab.PAYMENT -> strings.tabPayment
            MainTab.APPS -> strings.tabApps
            MainTab.ENGAGE -> strings.tabEngage
            MainTab.ACCOUNT -> strings.tabAccount
          }
        Box(
          modifier =
            Modifier.weight(1f)
              .height(60.dp)
              .clickable { onSelectTab(tab) }
              .testTag("nav_tab_${tab.route}"),
          contentAlignment = Alignment.Center,
        ) {
          if (selected) {
            Box(
              modifier =
                Modifier.align(Alignment.TopCenter)
                  .offset(y = (-6).dp)
                  .size(16.dp)
                  .clip(CircleShape)
                  .background(Color.White),
              contentAlignment = Alignment.Center,
            ) {
              Box(
                modifier = Modifier.size(9.dp).clip(CircleShape).background(TelebirrGreen)
              )
            }
          }
          Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center,
            modifier = Modifier.padding(top = 4.dp),
          ) {
            Icon(
              imageVector = if (selected) tab.selectedIcon else tab.unselectedIcon,
              contentDescription = tabLabel,
              tint = if (selected) Color.White else Color.White.copy(alpha = 0.85f),
              modifier = Modifier.size(22.dp),
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
              text = tabLabel,
              fontSize = 11.sp,
              fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
              color = if (selected) Color.White else Color.White.copy(alpha = 0.85f),
            )
          }
        }
      }
    }
  }
}
