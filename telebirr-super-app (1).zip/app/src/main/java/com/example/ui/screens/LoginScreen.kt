package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TelebirrCatalog
import com.example.ui.components.LoginWavesBackground
import com.example.ui.components.TelebirrTopBrandHeader
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrBorder
import com.example.ui.theme.TelebirrError
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextMuted
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary
import com.example.ui.theme.TelebirrUiStrings

@Composable
fun LoginScreen(
  phoneInput: String,
  selectedLanguage: String,
  errorMessage: String?,
  onPhoneChange: (String) -> Unit,
  onSelectLanguage: (String) -> Unit,
  onLoginClick: () -> Unit,
) {
  val strings = TelebirrUiStrings.forLanguage(LocalIsAmharic.current)
  var showLangMenu by remember { mutableStateOf(false) }
  var infoDialogTitle by remember { mutableStateOf<String?>(null) }
  var infoDialogBody by remember { mutableStateOf("") }

  Column(
    modifier =
      Modifier.fillMaxSize()
        .background(Color.White)
  ) {
    // Top green accent status strip matching screenshot
    Box(
      modifier =
        Modifier.fillMaxWidth()
          .background(TelebirrGreen)
          .statusBarsPadding()
    )

    TelebirrTopBrandHeader(applyStatusBarPadding = false)

    Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
      LoginWavesBackground(modifier = Modifier.fillMaxSize())

      Column(
        modifier =
          Modifier.fillMaxSize()
            .verticalScroll(rememberScrollState())
            .navigationBarsPadding()
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        // Language selector row on top right
        Row(
          modifier = Modifier.fillMaxWidth().padding(top = 12.dp),
          horizontalArrangement = Arrangement.End,
        ) {
          Box {
            Row(
              modifier =
                Modifier.clip(RoundedCornerShape(8.dp))
                  .clickable { showLangMenu = true }
                  .padding(horizontal = 8.dp, vertical = 6.dp)
                  .testTag("login_language_button"),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = selectedLanguage.substringBefore(" "),
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                color = TelebirrTextPrimary,
              )
              Icon(
                imageVector = Icons.Filled.ArrowDropDown,
                contentDescription = "Select Language",
                tint = TelebirrTextPrimary,
                modifier = Modifier.size(20.dp),
              )
            }
            DropdownMenu(
              expanded = showLangMenu,
              onDismissRequest = { showLangMenu = false },
            ) {
              TelebirrCatalog.languages.forEach { lang ->
                DropdownMenuItem(
                  text = { Text(lang) },
                  onClick = {
                    onSelectLanguage(lang)
                    showLangMenu = false
                  },
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(52.dp))

        Text(
          text = strings.welcomeTitle,
          fontSize = 21.sp,
          fontWeight = FontWeight.Bold,
          color = TelebirrBlue,
          textAlign = TextAlign.Center,
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = strings.allInOne,
          fontSize = 16.sp,
          fontWeight = FontWeight.Bold,
          color = TelebirrBlue,
        )

        Spacer(modifier = Modifier.height(18.dp))

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
          Text(
            text = strings.loginTitle,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = TelebirrTextPrimary,
          )
          Spacer(modifier = Modifier.height(6.dp))
          Box(
            modifier =
              Modifier.width(56.dp)
                .height(3.dp)
                .clip(RoundedCornerShape(2.dp))
                .background(TelebirrGreen)
          )
        }

        Spacer(modifier = Modifier.height(32.dp))

        Column(modifier = Modifier.widthIn(max = 520.dp).fillMaxWidth()) {
          Text(
            text = strings.mobileNumberLabel,
            fontSize = 14.sp,
            color = TelebirrTextSecondary,
            modifier = Modifier.padding(start = 4.dp, bottom = 8.dp),
          )

          Row(
            modifier =
              Modifier.fillMaxWidth()
                .height(52.dp)
                .clip(RoundedCornerShape(8.dp))
                .background(Color(0xFFF3F4F6))
                .border(
                  width = 1.dp,
                  color = if (errorMessage != null) TelebirrError else TelebirrBorder,
                  shape = RoundedCornerShape(8.dp),
                )
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "+251",
              fontSize = 16.sp,
              fontWeight = FontWeight.Medium,
              color = TelebirrTextPrimary,
            )
            Spacer(modifier = Modifier.width(14.dp))
            BasicTextField(
              value = phoneInput,
              onValueChange = onPhoneChange,
              singleLine = true,
              textStyle =
                TextStyle(
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Medium,
                  color = TelebirrTextPrimary,
                ),
              cursorBrush = SolidColor(TelebirrBlue),
              keyboardOptions =
                KeyboardOptions(
                  keyboardType = KeyboardType.Phone,
                  imeAction = ImeAction.Done,
                ),
              keyboardActions = KeyboardActions(onDone = { onLoginClick() }),
              modifier = Modifier.weight(1f).testTag("login_phone_input"),
              decorationBox = { innerTextField ->
                if (phoneInput.isEmpty()) {
                  Text(
                    text = "9XXXXXXXX",
                    fontSize = 16.sp,
                    color = TelebirrTextMuted,
                  )
                }
                innerTextField()
              },
            )
          }

          if (errorMessage != null) {
            Spacer(modifier = Modifier.height(6.dp))
            Text(
              text = errorMessage,
              fontSize = 12.sp,
              color = TelebirrError,
              modifier = Modifier.padding(start = 4.dp),
            )
          }

          Spacer(modifier = Modifier.height(26.dp))

          Button(
            onClick = onLoginClick,
            shape = RoundedCornerShape(10.dp),
            colors =
              ButtonDefaults.buttonColors(
                containerColor = TelebirrBlue,
                contentColor = Color.White,
              ),
            modifier =
              Modifier.fillMaxWidth()
                .height(50.dp)
                .testTag("login_next_button"),
          ) {
            Text(
              text = strings.next,
              fontSize = 16.sp,
              fontWeight = FontWeight.SemiBold,
            )
          }

          Spacer(modifier = Modifier.height(20.dp))

          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = strings.noAccountPrompt,
              fontSize = 13.sp,
              color = TelebirrTextPrimary,
            )
            Text(
              text = strings.createNewAccount,
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
              color = TelebirrGreen,
              modifier =
                Modifier.clickable {
                  infoDialogTitle = strings.createNewAccount
                  infoDialogBody =
                    "Register with your Ethio telecom SIM (+251) and Fayda National Digital ID to activate a new telebirr SuperApp wallet."
                },
            )
          }

          Spacer(modifier = Modifier.height(18.dp))

          Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp),
            horizontalArrangement = Arrangement.SpaceAround,
          ) {
            Text(
              text = strings.teleHub,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = TelebirrGreen,
              modifier =
                Modifier.clickable {
                  infoDialogTitle = strings.teleHub
                  infoDialogBody =
                    "Discover Ethio telecom service centers, SIM services, and telebirr agent locations near you."
                }.padding(8.dp),
            )
            Text(
              text = strings.help,
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = TelebirrGreen,
              modifier =
                Modifier.clickable {
                  infoDialogTitle = "telebirr Customer Support"
                  infoDialogBody =
                    "Call 127 (toll-free) for Ethio telecom & telebirr 24/7 customer assistance or visit any Ethio telecom shop."
                }.padding(8.dp),
            )
          }
        }

        Spacer(modifier = Modifier.weight(1f, fill = true))
        Spacer(modifier = Modifier.height(64.dp))

        Text(
          text = strings.termsAndConditions,
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium,
          color = TelebirrGreen,
          modifier =
            Modifier.clickable {
              infoDialogTitle = strings.termsAndConditions
              infoDialogBody =
                "Telebirr mobile money services are provided by Ethio telecom under National Bank of Ethiopia regulations. Keep your PIN confidential."
            }.padding(6.dp),
        )

        Spacer(modifier = Modifier.height(6.dp))

        Text(
          text = "@2026 Ethio telecom.All rights reserved 1.3.3\nversion",
          fontSize = 12.sp,
          color = Color(0xFFB6BCC4),
          textAlign = TextAlign.Center,
          lineHeight = 16.sp,
          modifier = Modifier.padding(bottom = 18.dp),
        )
      }
    }
  }

  if (infoDialogTitle != null) {
    AlertDialog(
      onDismissRequest = { infoDialogTitle = null },
      title = { Text(infoDialogTitle ?: "", fontWeight = FontWeight.Bold) },
      text = { Text(infoDialogBody, color = TelebirrTextSecondary) },
      confirmButton = {
        TextButton(onClick = { infoDialogTitle = null }) {
          Text("OK", color = TelebirrBlue, fontWeight = FontWeight.SemiBold)
        }
      },
    )
  }
}
