package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apartment
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.MiniAppItem
import com.example.data.SmsNotificationItem
import com.example.data.TelebirrCatalog
import com.example.ui.components.MiniAppBadge
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrDivider
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary

@Composable
fun TelebirrSmsAlertOverlay(
  smsBanner: SmsNotificationItem?,
  onDismiss: () -> Unit,
  modifier: Modifier = Modifier,
) {
  AnimatedVisibility(
    visible = smsBanner != null,
    enter = slideInVertically(initialOffsetY = { -it }),
    exit = slideOutVertically(targetOffsetY = { -it }),
    modifier = modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 10.dp, vertical = 6.dp),
  ) {
    if (smsBanner != null) {
      Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 10.dp),
        modifier = Modifier.fillMaxWidth(),
      ) {
        Column(modifier = Modifier.fillMaxWidth()) {
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .background(Color(0xFF0B72E7))
                .padding(horizontal = 14.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically,
          ) {
            Text(
              text = "SMS • ${smsBanner.timeLabel}",
              color = Color.White,
              fontSize = 13.sp,
              fontWeight = FontWeight.SemiBold,
            )
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Dismiss SMS Alert",
              tint = Color.White,
              modifier = Modifier.size(18.dp).clickable { onDismiss() },
            )
          }

          Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                modifier =
                  Modifier.size(34.dp).clip(CircleShape).background(Color(0xFF1F2A44)),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Filled.Apartment,
                  contentDescription = null,
                  tint = Color.White,
                  modifier = Modifier.size(18.dp),
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Text(
                text = smsBanner.title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = TelebirrTextSecondary,
              )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(
              text = smsBanner.body,
              fontSize = 13.sp,
              lineHeight = 18.sp,
              fontWeight = FontWeight.Medium,
              color = TelebirrTextPrimary,
            )
          }

          HorizontalDivider(color = TelebirrDivider)
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clickable { onDismiss() }
                .padding(vertical = 12.dp),
            contentAlignment = Alignment.Center,
          ) {
            Text(
              text = "Mark as read",
              fontSize = 14.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF0B72E7),
            )
          }
        }
      }
    }
  }
}

@Composable
fun CashInDialog(
  onDismiss: () -> Unit,
  onConfirmCashIn: (String) -> Unit,
) {
  var amount by remember { mutableStateOf("100") }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Cash In / Out", fontWeight = FontWeight.Bold) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
          "Top up your Telebirr wallet balance instantly via Ethio telecom agent or linked bank:",
          fontSize = 13.sp,
          color = TelebirrTextSecondary,
        )
        OutlinedTextField(
          value = amount,
          onValueChange = { amount = it.filter { ch -> ch.isDigit() || ch == '.' } },
          label = { Text("Amount (ETB)") },
          keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onConfirmCashIn(amount) },
        colors = ButtonDefaults.buttonColors(containerColor = TelebirrGreen),
      ) {
        Text("Add Funds", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Cancel") }
    },
  )
}

@Composable
fun NotificationsInboxDialog(
  items: List<SmsNotificationItem>,
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Messages & Alerts", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        items.take(8).forEach { item ->
          Box(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFF3F4F6))
                .padding(12.dp)
          ) {
            Column(modifier = Modifier.fillMaxWidth()) {
              Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
              ) {
                Text(
                  item.title,
                  fontWeight = FontWeight.SemiBold,
                  fontSize = 12.sp,
                  color = TelebirrBlue,
                )
                Text(item.timeLabel, fontSize = 11.sp, color = TelebirrTextSecondary)
              }
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                item.body,
                fontSize = 13.sp,
                lineHeight = 18.sp,
                color = TelebirrTextPrimary,
              )
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Close", color = TelebirrBlue) }
    },
  )
}

@Composable
fun QrActionDialog(
  userName: String,
  phoneNumber: String,
  onDismiss: () -> Unit,
  onScanPayMerchant: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("telebirr QR", fontWeight = FontWeight.Bold) },
    text = {
      Column(
        modifier = Modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Icon(
          imageVector = Icons.Filled.QrCode2,
          contentDescription = "My Telebirr QR Code",
          tint = TelebirrTextPrimary,
          modifier = Modifier.size(130.dp),
        )
        Text(
          text = "$userName • +251$phoneNumber",
          fontWeight = FontWeight.SemiBold,
          color = TelebirrTextPrimary,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
          text = "Show this QR code to receive money or tap below to pay a merchant QR.",
          fontSize = 12.sp,
          color = TelebirrTextSecondary,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onScanPayMerchant,
        colors = ButtonDefaults.buttonColors(containerColor = TelebirrBlue),
      ) {
        Icon(Icons.Filled.QrCodeScanner, null, modifier = Modifier.size(18.dp))
        Spacer(modifier = Modifier.width(6.dp))
        Text("Pay Merchant QR")
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Close") }
    },
  )
}

@Composable
fun MiniAppDetailDialog(
  app: MiniAppItem,
  onDismiss: () -> Unit,
  onPayWithTelebirr: (MiniAppItem) -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        MiniAppBadge(app.iconKey)
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(app.title.replace("\n", " "), fontWeight = FontWeight.Bold, fontSize = 16.sp)
          Text(app.category, fontSize = 12.sp, color = TelebirrGreen)
        }
      }
    },
    text = {
      Text(app.description, fontSize = 14.sp, color = TelebirrTextSecondary)
    },
    confirmButton = {
      Button(
        onClick = { onPayWithTelebirr(app) },
        colors = ButtonDefaults.buttonColors(containerColor = TelebirrGreen),
      ) {
        Text("Pay / Open Service", color = Color.White)
      }
    },
    dismissButton = {
      TextButton(onClick = onDismiss) { Text("Close") }
    },
  )
}

@Composable
fun GlobalSearchDialog(
  onDismiss: () -> Unit,
  onSelectMiniApp: (MiniAppItem) -> Unit,
) {
  var query by remember { mutableStateOf("") }
  val results =
    remember(query) {
      if (query.isBlank()) TelebirrCatalog.miniApps.take(5)
      else {
        val q = query.trim().lowercase()
        TelebirrCatalog.miniApps.filter { it.title.lowercase().contains(q) }.take(6)
      }
    }
  AlertDialog(
    onDismissRequest = onDismiss,
    title = { Text("Search telebirr SuperApp", fontWeight = FontWeight.Bold) },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        OutlinedTextField(
          value = query,
          onValueChange = { query = it },
          placeholder = { Text("Search services, mini-apps...") },
          singleLine = true,
          modifier = Modifier.fillMaxWidth(),
        )
        results.forEach { app ->
          Row(
            modifier =
              Modifier.fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .clickable { onSelectMiniApp(app) }
                .padding(vertical = 6.dp, horizontal = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            MiniAppBadge(app.iconKey)
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(app.title.replace("\n", " "), fontWeight = FontWeight.Medium, fontSize = 14.sp)
              Text(app.category, fontSize = 11.sp, color = TelebirrTextSecondary)
            }
          }
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("Close", color = TelebirrBlue) }
    },
  )
}

@Composable
fun NearbyAgentsDialog(onDismiss: () -> Unit) {
  AlertDialog(
    onDismissRequest = onDismiss,
    title = {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Filled.LocationOn, null, tint = TelebirrGreen)
        Spacer(modifier = Modifier.width(8.dp))
        Text("Nearby telebirr Agents", fontWeight = FontWeight.Bold)
      }
    },
    text = {
      Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        listOf(
          "Ethio telecom Bole Service Center" to "0.4 km • Open until 8:00 PM",
          "telebirr Express Agent - Churchill Rd" to "0.9 km • Cash In / Cash Out",
          "Zemen Supermarket Telebirr Desk" to "1.3 km • Merchant & Cash In",
        ).forEach { (name, detail) ->
          Column {
            Text(name, fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
            Text(detail, fontSize = 12.sp, color = TelebirrTextSecondary)
          }
          HorizontalDivider(color = TelebirrDivider)
        }
      }
    },
    confirmButton = {
      TextButton(onClick = onDismiss) { Text("OK", color = TelebirrBlue) }
    },
  )
}
