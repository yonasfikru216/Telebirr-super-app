package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.outlined.Backspace
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.TelebirrRepository
import com.example.ui.components.RecipientAvatar
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrBackground
import com.example.ui.theme.TelebirrDivider
import com.example.ui.theme.TelebirrError
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrGreenDisabled
import com.example.ui.theme.TelebirrTextMuted
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary
import com.example.ui.theme.TelebirrUiStrings
import com.example.ui.viewmodel.SendMoneyDraft
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SendMoneyAmountScreen(
  draft: SendMoneyDraft,
  availableBalance: Double,
  serviceFee: Double,
  errorMessage: String?,
  isProcessing: Boolean,
  onBack: () -> Unit,
  onEditRecipientDetails: (name: String, phone: String) -> Unit,
  onKeypadPress: (String) -> Unit,
  onNotesChange: (String) -> Unit,
  onConfirmSend: () -> Unit,
  onDismissError: () -> Unit,
) {
  val strings = TelebirrUiStrings.forLanguage(LocalIsAmharic.current)
  var showConfirmSheet by remember { mutableStateOf(false) }
  var showEditRecipientDialog by remember { mutableStateOf(false) }

  val numericAmount = draft.amountInput.toDoubleOrNull() ?: 0.0
  val isValidAmount = numericAmount > 0.0
  val normalizedPhone = TelebirrRepository.normalizeEthiopianPhone(draft.recipientPhone)

  Column(
    modifier =
      Modifier.fillMaxSize()
        .background(TelebirrBackground)
        .statusBarsPadding()
        .navigationBarsPadding()
  ) {
    // Top bar
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(Color.White)
          .padding(horizontal = 6.dp, vertical = 8.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(onClick = onBack, modifier = Modifier.testTag("amount_back_button")) {
        Icon(
          imageVector = Icons.AutoMirrored.Filled.ArrowBack,
          contentDescription = "Back",
          tint = TelebirrTextPrimary,
        )
      }
      Spacer(modifier = Modifier.width(6.dp))
      Text(
        text = strings.sendMoney,
        fontSize = 18.sp,
        fontWeight = FontWeight.Bold,
        color = TelebirrTextPrimary,
      )
    }

    // Recipient Header (tappable to edit Transaction Name & Number)
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(TelebirrBackground)
          .clickable { showEditRecipientDialog = true }
          .padding(horizontal = 16.dp, vertical = 14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      RecipientAvatar(avatarKey = draft.avatarKey, size = 46.dp, cornerRadius = 8.dp)
      Spacer(modifier = Modifier.width(12.dp))
      Column(modifier = Modifier.weight(1f)) {
        Text(
          text = draft.recipientName.ifEmpty { "Recipient" },
          fontSize = 16.sp,
          fontWeight = FontWeight.SemiBold,
          color = TelebirrTextPrimary,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = normalizedPhone,
          fontSize = 13.sp,
          color = TelebirrTextSecondary,
        )
      }
      IconButton(
        onClick = { showEditRecipientDialog = true },
        modifier = Modifier.size(36.dp).testTag("edit_recipient_details_button"),
      ) {
        Icon(
          imageVector = Icons.Outlined.Edit,
          contentDescription = "Edit Transaction Name and Number",
          tint = TelebirrGreen,
          modifier = Modifier.size(20.dp),
        )
      }
    }

    // Amount & Notes Card
    Surface(
      modifier = Modifier.fillMaxWidth().weight(1f),
      shape = RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp),
      color = Color.White,
    ) {
      Column(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 20.dp)) {
        Text(
          text = strings.amount,
          fontSize = 14.sp,
          fontWeight = FontWeight.Medium,
          color = TelebirrTextPrimary,
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
        ) {
          Text(
            text = draft.amountInput.ifEmpty { "" },
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            color = TelebirrTextPrimary,
            modifier = Modifier.weight(1f).testTag("amount_display_text"),
          )
          Box(
            modifier =
              Modifier.width(1.dp)
                .height(22.dp)
                .background(TelebirrDivider)
          )
          Spacer(modifier = Modifier.width(12.dp))
          Text(
            text = "(ETB)",
            fontSize = 15.sp,
            color = TelebirrTextMuted,
          )
        }

        HorizontalDivider(color = TelebirrDivider)
        Spacer(modifier = Modifier.height(14.dp))

        BasicTextField(
          value = draft.notes,
          onValueChange = onNotesChange,
          singleLine = true,
          textStyle = TextStyle(fontSize = 14.sp, color = TelebirrTextPrimary),
          cursorBrush = SolidColor(TelebirrGreen),
          modifier = Modifier.fillMaxWidth().testTag("amount_notes_input"),
          decorationBox = { inner ->
            if (draft.notes.isEmpty()) {
              Text(
                text = strings.addNotesHint,
                fontSize = 14.sp,
                color = Color(0xFF607080),
              )
            }
            inner()
          },
        )
      }
    }

    // Custom Numeric Keypad matching Screenshot_20261122-111429_telebirr_032aebc5.jpg
    Column(
      modifier =
        Modifier.fillMaxWidth()
          .background(Color(0xFFF3F4F6))
          .padding(horizontal = 6.dp, vertical = 6.dp)
    ) {
      Box(
        modifier = Modifier.fillMaxWidth().padding(bottom = 4.dp),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Filled.KeyboardArrowDown,
          contentDescription = null,
          tint = Color(0xFFBDC3C7),
          modifier = Modifier.size(20.dp),
        )
      }

      // Row 1: 1, 2, 3, Backspace
      Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        KeypadDigitButton("1", Modifier.weight(1f)) { onKeypadPress("1") }
        KeypadDigitButton("2", Modifier.weight(1f)) { onKeypadPress("2") }
        KeypadDigitButton("3", Modifier.weight(1f)) { onKeypadPress("3") }
        Surface(
          onClick = { onKeypadPress("BACKSPACE") },
          shape = RoundedCornerShape(6.dp),
          color = Color.White,
          modifier = Modifier.weight(1f).height(52.dp).testTag("keypad_backspace"),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Icon(
              imageVector = Icons.AutoMirrored.Outlined.Backspace,
              contentDescription = "Backspace",
              tint = TelebirrTextPrimary,
              modifier = Modifier.size(22.dp),
            )
          }
        }
      }

      Spacer(modifier = Modifier.height(6.dp))

      // Rows 2-4: left 3 columns + tall OK button on column 4
      Row(
        modifier = Modifier.fillMaxWidth().height(IntrinsicSize.Min),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
      ) {
        Column(
          modifier = Modifier.weight(3f),
          verticalArrangement = Arrangement.spacedBy(6.dp),
        ) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            KeypadDigitButton("4", Modifier.weight(1f)) { onKeypadPress("4") }
            KeypadDigitButton("5", Modifier.weight(1f)) { onKeypadPress("5") }
            KeypadDigitButton("6", Modifier.weight(1f)) { onKeypadPress("6") }
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            KeypadDigitButton("7", Modifier.weight(1f)) { onKeypadPress("7") }
            KeypadDigitButton("8", Modifier.weight(1f)) { onKeypadPress("8") }
            KeypadDigitButton("9", Modifier.weight(1f)) { onKeypadPress("9") }
          }
          Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            KeypadDigitButton("0", Modifier.weight(2f)) { onKeypadPress("0") }
            KeypadDigitButton(".", Modifier.weight(1f)) { onKeypadPress(".") }
          }
        }

        // Tall OK Button spanning 3 rows
        Surface(
          onClick = {
            if (isValidAmount) {
              onDismissError()
              showConfirmSheet = true
            }
          },
          shape = RoundedCornerShape(6.dp),
          color = if (isValidAmount) TelebirrGreen else TelebirrGreenDisabled,
          modifier =
            Modifier.weight(1f)
              .fillMaxHeight()
              .testTag("keypad_ok_button"),
        ) {
          Box(contentAlignment = Alignment.Center) {
            Text(
              text = strings.ok,
              fontSize = 18.sp,
              fontWeight = FontWeight.Bold,
              color = Color.White,
            )
          }
        }
      }
    }
  }

  // Confirmation Bottom Sheet matching Screenshot_20261122-111435_telebirr_ec42567e.jpg
  if (showConfirmSheet) {
    val total = ((numericAmount + serviceFee) * 100).toLong() / 100.0
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
      onDismissRequest = {
        showConfirmSheet = false
        onDismissError()
      },
      sheetState = sheetState,
      containerColor = Color(0xFFF6F7F9),
      dragHandle = null,
      shape = RoundedCornerShape(topStart = 18.dp, topEnd = 18.dp),
    ) {
      Column(
        modifier =
          Modifier.fillMaxWidth()
            .navigationBarsPadding()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Box(modifier = Modifier.fillMaxWidth()) {
          IconButton(
            onClick = {
              showConfirmSheet = false
              onDismissError()
            },
            modifier = Modifier.align(Alignment.CenterStart).size(40.dp),
          ) {
            Icon(
              imageVector = Icons.Filled.Close,
              contentDescription = "Close",
              tint = TelebirrTextPrimary,
            )
          }
        }

        Text(
          text = "${strings.sendMoneyToPrefix} ${draft.recipientName.ifEmpty { "Recipient" }}",
          fontSize = 16.sp,
          fontWeight = FontWeight.Medium,
          color = TelebirrTextPrimary,
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
          text = normalizedPhone,
          fontSize = 12.sp,
          color = TelebirrTextSecondary,
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
          text =
            buildAnnotatedString {
              withStyle(SpanStyle(fontSize = 32.sp, fontWeight = FontWeight.Bold)) {
                append(String.format(Locale.US, "%.2f", total))
              }
              withStyle(SpanStyle(fontSize = 15.sp, fontWeight = FontWeight.Bold)) {
                append("ETB")
              }
            },
          color = Color.Black,
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Amount & Service Fee Card
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(strings.originalAmount, fontSize = 14.sp, color = TelebirrTextSecondary)
              Text(
                text = "${String.format(Locale.US, "%.2f", numericAmount)}ETB",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = TelebirrTextPrimary,
              )
            }
            Spacer(modifier = Modifier.height(14.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.SpaceBetween,
            ) {
              Text(strings.serviceFee, fontSize = 14.sp, color = TelebirrTextSecondary)
              Text(
                text = "${String.format(Locale.US, "%.2f", serviceFee)}ETB",
                fontSize = 14.sp,
                fontWeight = FontWeight.Medium,
                color = TelebirrTextPrimary,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Payment Method Card
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          modifier = Modifier.fillMaxWidth(),
        ) {
          Column(modifier = Modifier.fillMaxWidth().padding(16.dp)) {
            Text(strings.paymentMethod, fontSize = 14.sp, color = TelebirrTextSecondary)
            Spacer(modifier = Modifier.height(12.dp))
            Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Filled.AccountBalanceWallet,
                contentDescription = null,
                tint = TelebirrGreen,
                modifier = Modifier.size(28.dp),
              )
              Spacer(modifier = Modifier.width(12.dp))
              Column(modifier = Modifier.weight(1f)) {
                Text(
                  text = strings.balance,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Medium,
                  color = TelebirrTextPrimary,
                )
                Text(
                  text = "(${strings.availableBalancePrefix}${String.format(Locale.US, "%,.2f", availableBalance)}ETB)",
                  fontSize = 13.sp,
                  color = TelebirrTextSecondary,
                )
              }
              Box(
                modifier = Modifier.size(20.dp).clip(CircleShape).background(TelebirrGreen),
                contentAlignment = Alignment.Center,
              ) {
                Icon(
                  imageVector = Icons.Filled.Check,
                  contentDescription = "Selected",
                  tint = Color.White,
                  modifier = Modifier.size(13.dp),
                )
              }
            }
          }
        }

        if (errorMessage != null) {
          Spacer(modifier = Modifier.height(10.dp))
          Text(
            text = errorMessage,
            fontSize = 13.sp,
            color = TelebirrError,
            fontWeight = FontWeight.Medium,
          )
        }

        Spacer(modifier = Modifier.height(18.dp))

        Button(
          onClick = {
            if (!isProcessing) {
              onConfirmSend()
            }
          },
          enabled = !isProcessing,
          shape = RoundedCornerShape(10.dp),
          colors =
            ButtonDefaults.buttonColors(
              containerColor = TelebirrGreen,
              contentColor = Color.White,
            ),
          modifier =
            Modifier.fillMaxWidth()
              .height(50.dp)
              .testTag("confirm_send_button"),
        ) {
          Text(
            text = if (isProcessing) strings.sending else strings.send,
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
          )
        }

        Spacer(modifier = Modifier.height(8.dp))
      }
    }
  }

  if (showEditRecipientDialog) {
    var editName by remember(draft.recipientName) { mutableStateOf(draft.recipientName) }
    var editPhone by remember(draft.recipientPhone) { mutableStateOf(draft.recipientPhone) }
    AlertDialog(
      onDismissRequest = { showEditRecipientDialog = false },
      title = { Text("Transaction Name & Number", fontWeight = FontWeight.Bold) },
      text = {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
          OutlinedTextField(
            value = editName,
            onValueChange = { editName = it },
            label = { Text("Transaction / Recipient Name") },
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
          OutlinedTextField(
            value = editPhone,
            onValueChange = { editPhone = it.filter { ch -> ch.isDigit() }.take(12) },
            label = { Text("Mobile / Account Number (+251)") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
            singleLine = true,
            modifier = Modifier.fillMaxWidth(),
          )
        }
      },
      confirmButton = {
        Button(
          onClick = {
            if (editName.trim().isNotEmpty()) {
              onEditRecipientDetails(editName.trim(), editPhone)
              showEditRecipientDialog = false
            }
          },
          colors = ButtonDefaults.buttonColors(containerColor = TelebirrGreen),
        ) {
          Text("Save", color = Color.White)
        }
      },
      dismissButton = {
        TextButton(onClick = { showEditRecipientDialog = false }) { Text("Cancel") }
      },
    )
  }
}

@Composable
private fun KeypadDigitButton(
  label: String,
  modifier: Modifier = Modifier,
  onClick: () -> Unit,
) {
  Surface(
    onClick = onClick,
    shape = RoundedCornerShape(6.dp),
    color = Color.White,
    modifier = modifier.height(52.dp).testTag("keypad_btn_$label"),
  ) {
    Box(contentAlignment = Alignment.Center) {
      Text(
        text = label,
        fontSize = 22.sp,
        fontWeight = FontWeight.Bold,
        color = Color.Black,
      )
    }
  }
}
