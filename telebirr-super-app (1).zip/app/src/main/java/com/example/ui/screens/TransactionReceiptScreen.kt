package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material.icons.outlined.Download
import androidx.compose.material.icons.outlined.QrCode2
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.data.TransactionEntity
import com.example.ui.theme.LocalIsAmharic
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrDivider
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary
import com.example.ui.theme.TelebirrUiStrings
import com.example.util.ReceiptDownloadHelper
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun TransactionReceiptScreen(
  transaction: TransactionEntity,
  onDownloadMessage: (String) -> Unit,
  onFinished: () -> Unit,
) {
  val strings = TelebirrUiStrings.forLanguage(LocalIsAmharic.current)
  val context = LocalContext.current
  val coroutineScope = rememberCoroutineScope()
  val pagerState = rememberPagerState(pageCount = { 2 })
  var showQrDialog by remember { mutableStateOf(false) }
  var isDownloading by remember { mutableStateOf(false) }

  Column(
    modifier =
      Modifier.fillMaxSize()
        .background(Color.White)
        .statusBarsPadding()
        .navigationBarsPadding()
        .verticalScroll(rememberScrollState())
        .padding(horizontal = 18.dp, vertical = 14.dp),
    horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // Top Download / Share Row
    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(
        modifier =
          Modifier.clip(RoundedCornerShape(8.dp))
            .clickable(enabled = !isDownloading) {
              isDownloading = true
              coroutineScope.launch {
                val result =
                  withContext(Dispatchers.IO) {
                    ReceiptDownloadHelper.saveReceiptImageToDownloads(context, transaction)
                  }
                isDownloading = false
                result
                  .onSuccess { savedPath ->
                    onDownloadMessage("Receipt saved to $savedPath")
                  }
                  .onFailure { error ->
                    onDownloadMessage(
                      error.localizedMessage ?: "Unable to save receipt image"
                    )
                  }
              }
            }
            .padding(horizontal = 6.dp, vertical = 8.dp)
            .testTag("receipt_download_button"),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector = Icons.Outlined.Download,
          contentDescription = "Download Receipt",
          tint = TelebirrGreen,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = if (isDownloading) strings.saving else strings.download,
          fontSize = 15.sp,
          fontWeight = FontWeight.Medium,
          color = TelebirrGreen,
        )
      }

      Row(
        modifier =
          Modifier.clip(RoundedCornerShape(8.dp))
            .clickable {
              val shareText = ReceiptDownloadHelper.buildReceiptShareText(transaction)
              val intent =
                Intent(Intent.ACTION_SEND).apply {
                  type = "text/plain"
                  putExtra(Intent.EXTRA_TEXT, shareText)
                }
              context.startActivity(Intent.createChooser(intent, "Share telebirr receipt"))
            }
            .padding(horizontal = 6.dp, vertical = 8.dp)
            .testTag("receipt_share_button"),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector = Icons.Outlined.Share,
          contentDescription = "Share Receipt",
          tint = TelebirrGreen,
          modifier = Modifier.size(20.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = strings.share,
          fontSize = 15.sp,
          fontWeight = FontWeight.Medium,
          color = TelebirrGreen,
        )
      }
    }

    Spacer(modifier = Modifier.height(10.dp))

    // Green Success Check Circle
    Box(
      modifier = Modifier.size(52.dp).clip(CircleShape).background(TelebirrGreen),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = Icons.Filled.Check,
        contentDescription = "Successful",
        tint = Color.White,
        modifier = Modifier.size(30.dp),
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Text(
      text = strings.successful,
      fontSize = 16.sp,
      fontWeight = FontWeight.Medium,
      color = TelebirrGreen,
    )

    Spacer(modifier = Modifier.height(44.dp))

    // -6.00 (ETB)
    Text(
      text =
        buildAnnotatedString {
          withStyle(SpanStyle(fontSize = 32.sp, fontWeight = FontWeight.Medium)) {
            append("-${String.format(Locale.US, "%.2f", transaction.totalAmount)} ")
          }
          withStyle(SpanStyle(fontSize = 15.sp, fontWeight = FontWeight.Normal)) {
            append("(ETB)")
          }
        },
      color = Color.Black,
      modifier = Modifier.testTag("receipt_amount_text"),
    )

    Spacer(modifier = Modifier.height(34.dp))

    HorizontalDivider(color = TelebirrDivider)
    Spacer(modifier = Modifier.height(16.dp))

    ReceiptDetailRow(strings.transactionTime, transaction.formattedTime)
    Spacer(modifier = Modifier.height(16.dp))
    ReceiptDetailRow(strings.transactionType, transaction.transactionType)
    Spacer(modifier = Modifier.height(16.dp))
    ReceiptDetailRow(strings.transactionTo, transaction.recipientName)
    Spacer(modifier = Modifier.height(16.dp))
    ReceiptDetailRow(strings.recipientNumber, transaction.recipientPhone)
    Spacer(modifier = Modifier.height(16.dp))
    ReceiptDetailRow(strings.transactionNumber, transaction.transactionNumber)
    if (transaction.notes.isNotBlank()) {
      Spacer(modifier = Modifier.height(16.dp))
      ReceiptDetailRow(strings.notes, transaction.notes)
    }

    Spacer(modifier = Modifier.height(20.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.End,
    ) {
      Row(
        modifier =
          Modifier.clip(RoundedCornerShape(8.dp))
            .clickable { showQrDialog = true }
            .padding(horizontal = 6.dp, vertical = 6.dp)
            .testTag("receipt_qr_button"),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
          imageVector = Icons.Outlined.QrCode2,
          contentDescription = "QR Code",
          tint = TelebirrGreen,
          modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
          text = strings.qrCode,
          fontSize = 15.sp,
          fontWeight = FontWeight.SemiBold,
          color = TelebirrGreen,
        )
      }
    }

    Spacer(modifier = Modifier.height(18.dp))

    // Banner Pager matching screenshot
    HorizontalPager(
      state = pagerState,
      modifier = Modifier.fillMaxWidth(),
    ) { page ->
      val resId =
        if (page == 0) R.drawable.banner_zemen_gebeya else R.drawable.banner_fayda
      Image(
        painter = painterResource(id = resId),
        contentDescription = "Telebirr Banner",
        modifier =
          Modifier.fillMaxWidth()
            .height(112.dp)
            .clip(RoundedCornerShape(12.dp)),
        contentScale = ContentScale.Crop,
      )
    }

    Spacer(modifier = Modifier.height(10.dp))

    Row(
      modifier = Modifier.fillMaxWidth(),
      horizontalArrangement = Arrangement.Center,
    ) {
      repeat(2) { index ->
        val active = pagerState.currentPage == index
        Box(
          modifier =
            Modifier.padding(horizontal = 3.dp)
              .size(7.dp)
              .clip(CircleShape)
              .background(if (active) TelebirrGreen else Color.Transparent)
              .border(1.dp, TelebirrGreen, CircleShape)
        )
      }
    }

    Spacer(modifier = Modifier.height(34.dp))

    Button(
      onClick = onFinished,
      shape = RoundedCornerShape(8.dp),
      colors =
        ButtonDefaults.buttonColors(
          containerColor = TelebirrGreen,
          contentColor = Color.White,
        ),
      modifier =
        Modifier.width(196.dp)
          .height(48.dp)
          .testTag("receipt_finished_button"),
    ) {
      Text(
        text = strings.finished,
        fontSize = 16.sp,
        fontWeight = FontWeight.SemiBold,
      )
    }

    Spacer(modifier = Modifier.height(16.dp))
  }

  if (showQrDialog) {
    AlertDialog(
      onDismissRequest = { showQrDialog = false },
      title = { Text("Transaction QR Verification", fontWeight = FontWeight.Bold) },
      text = {
        Column(
          modifier = Modifier.fillMaxWidth(),
          horizontalAlignment = Alignment.CenterHorizontally,
        ) {
          Icon(
            imageVector = Icons.Filled.QrCode2,
            contentDescription = "Receipt QR",
            tint = TelebirrTextPrimary,
            modifier = Modifier.size(140.dp),
          )
          Spacer(modifier = Modifier.height(8.dp))
          Text(
            text = "Ref: ${transaction.transactionNumber}",
            fontWeight = FontWeight.SemiBold,
            color = TelebirrTextPrimary,
          )
          Text(
            text = "Paid to ${transaction.recipientName}",
            fontSize = 13.sp,
            color = TelebirrTextSecondary,
          )
        }
      },
      confirmButton = {
        TextButton(onClick = { showQrDialog = false }) {
          Text("Done", color = TelebirrBlue, fontWeight = FontWeight.SemiBold)
        }
      },
    )
  }
}

@Composable
private fun ReceiptDetailRow(label: String, value: String) {
  Row(
    modifier = Modifier.fillMaxWidth(),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    Text(
      text = label,
      fontSize = 14.sp,
      color = TelebirrTextSecondary,
    )
    Text(
      text = value,
      fontSize = 14.sp,
      fontWeight = FontWeight.Medium,
      color = TelebirrTextPrimary,
    )
  }
}
