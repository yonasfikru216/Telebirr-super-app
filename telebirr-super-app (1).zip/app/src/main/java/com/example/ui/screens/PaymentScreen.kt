package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.KeyboardArrowDown
import androidx.compose.material.icons.filled.KeyboardArrowUp
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.PaymentServiceItem
import com.example.data.TelebirrCatalog
import com.example.ui.components.PaymentServiceBadge
import com.example.ui.theme.TelebirrBackground
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrTextPrimary
import com.example.ui.theme.TelebirrTextSecondary

@Composable
fun PaymentScreen(
  onSelectService: (PaymentServiceItem) -> Unit,
) {
  var expandedId by remember { mutableStateOf<String?>("utility") }
  var showSearch by remember { mutableStateOf(false) }
  var searchQuery by remember { mutableStateOf("") }

  val filteredCategories =
    remember(searchQuery) {
      if (searchQuery.isBlank()) {
        TelebirrCatalog.paymentCategories
      } else {
        val q = searchQuery.trim().lowercase()
        TelebirrCatalog.paymentCategories.mapNotNull { cat ->
          val matchingServices = cat.services.filter { it.title.lowercase().contains(q) }
          if (cat.title.lowercase().contains(q)) cat
          else if (matchingServices.isNotEmpty()) cat.copy(services = matchingServices)
          else null
        }
      }
    }

  Column(modifier = Modifier.fillMaxSize().background(TelebirrBackground)) {
    // Green Header Bar
    Row(
      modifier =
        Modifier.fillMaxWidth()
          .background(TelebirrGreen)
          .statusBarsPadding()
          .padding(horizontal = 12.dp, vertical = 10.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Spacer(modifier = Modifier.size(40.dp))
      Text(
        text = "Payment",
        fontSize = 19.sp,
        fontWeight = FontWeight.Medium,
        color = Color.White,
        textAlign = TextAlign.Center,
        modifier = Modifier.weight(1f),
      )
      IconButton(
        onClick = {
          showSearch = !showSearch
          if (!showSearch) searchQuery = ""
        },
        modifier = Modifier.size(40.dp).testTag("payment_search_toggle"),
      ) {
        Icon(
          imageVector = if (showSearch) Icons.Filled.Close else Icons.Filled.Search,
          contentDescription = "Search Payment Services",
          tint = Color.White,
        )
      }
    }

    AnimatedVisibility(visible = showSearch) {
      OutlinedTextField(
        value = searchQuery,
        onValueChange = { searchQuery = it },
        placeholder = { Text("Search bills, utilities, transport...") },
        singleLine = true,
        shape = RoundedCornerShape(10.dp),
        modifier =
          Modifier.fillMaxWidth()
            .background(Color.White)
            .padding(horizontal = 14.dp, vertical = 10.dp),
      )
    }

    LazyColumn(
      modifier = Modifier.fillMaxSize().padding(horizontal = 14.dp),
      verticalArrangement = Arrangement.spacedBy(12.dp),
    ) {
      item { Spacer(modifier = Modifier.height(6.dp)) }

      items(filteredCategories, key = { it.id }) { category ->
        val isExpanded = expandedId == category.id || searchQuery.isNotBlank()
        Card(
          shape = RoundedCornerShape(12.dp),
          colors = CardDefaults.cardColors(containerColor = Color.White),
          elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
          modifier = Modifier.fillMaxWidth().testTag("payment_category_${category.id}"),
        ) {
          Column(modifier = Modifier.fillMaxWidth()) {
            // Category Header: Blue when Utility or expanded, White when collapsed
            val headerBg = if (isExpanded) TelebirrBlue else Color.White
            val headerText = if (isExpanded) Color.White else TelebirrTextPrimary
            Row(
              modifier =
                Modifier.fillMaxWidth()
                  .background(headerBg)
                  .clickable {
                    expandedId = if (expandedId == category.id) null else category.id
                  }
                  .padding(horizontal = 18.dp, vertical = 16.dp),
              horizontalArrangement = Arrangement.SpaceBetween,
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Text(
                text = category.title,
                fontSize = 16.sp,
                fontWeight = if (isExpanded) FontWeight.SemiBold else FontWeight.Medium,
                color = headerText,
              )
              Icon(
                imageVector =
                  if (isExpanded) Icons.Filled.KeyboardArrowUp
                  else Icons.Filled.KeyboardArrowDown,
                contentDescription = if (isExpanded) "Collapse" else "Expand",
                tint = if (isExpanded) Color.White else TelebirrTextSecondary,
              )
            }

            AnimatedVisibility(visible = isExpanded) {
              Column(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 14.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp),
              ) {
                val rows = category.services.chunked(4)
                rows.forEach { rowItems ->
                  Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.Start,
                  ) {
                    rowItems.forEach { service ->
                      Column(
                        modifier =
                          Modifier.weight(1f)
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectService(service) }
                            .padding(horizontal = 4.dp, vertical = 6.dp)
                            .testTag("payment_service_${service.id}"),
                        horizontalAlignment = Alignment.CenterHorizontally,
                      ) {
                        PaymentServiceBadge(service.iconKey)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                          text = service.title,
                          fontSize = 11.5.sp,
                          lineHeight = 14.sp,
                          color = TelebirrTextPrimary,
                          textAlign = TextAlign.Center,
                          maxLines = 3,
                          overflow = TextOverflow.Ellipsis,
                        )
                      }
                    }
                    repeat(4 - rowItems.size) {
                      Spacer(modifier = Modifier.weight(1f))
                    }
                  }
                }
              }
            }
          }
        }
      }

      item { Spacer(modifier = Modifier.height(14.dp)) }
    }
  }
}
