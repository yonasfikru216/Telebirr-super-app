package com.example.ui.screens

import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.ConcentricCirclesBackground
import com.example.ui.theme.TelebirrBlue
import com.example.ui.theme.TelebirrGold
import com.example.ui.theme.TelebirrGreen
import com.example.ui.theme.TelebirrGreenLight
import kotlinx.coroutines.delay

@Composable
fun SplashScreen(onFinished: () -> Unit) {
  val scale = remember { Animatable(0.9f) }
  val alpha = remember { Animatable(0f) }

  LaunchedEffect(Unit) {
    alpha.animateTo(1f, animationSpec = tween(450, easing = FastOutSlowInEasing))
    scale.animateTo(1f, animationSpec = tween(550, easing = FastOutSlowInEasing))
    delay(900L)
    onFinished()
  }

  Box(modifier = Modifier.fillMaxSize()) {
    ConcentricCirclesBackground(
      modifier = Modifier.fillMaxSize(),
      baseGradient = listOf(TelebirrGreenLight, TelebirrGreen),
    )

    Column(
      modifier =
        Modifier.align(Alignment.Center)
          .alpha(alpha.value)
          .scale(scale.value)
          .padding(horizontal = 32.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
    ) {
      Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
      ) {
        Box(
          modifier =
            Modifier.size(86.dp)
              .clip(RoundedCornerShape(20.dp))
              .background(Color.White.copy(alpha = 0.08f)),
          contentAlignment = Alignment.Center,
        ) {
          Image(
            painter = painterResource(id = R.drawable.ic_telebirr_swirl),
            contentDescription = "Telebirr SuperApp emblem",
            modifier = Modifier.size(74.dp),
            contentScale = ContentScale.Fit,
          )
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column {
          Text(
            text = "ቴሌብር",
            fontSize = 32.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TelebirrBlue,
            lineHeight = 34.sp,
          )
          Text(
            text = "telebirr",
            fontSize = 34.sp,
            fontWeight = FontWeight.ExtraBold,
            color = TelebirrGold,
            lineHeight = 36.sp,
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
        text =
          buildAnnotatedString {
            withStyle(SpanStyle(color = TelebirrBlue, fontWeight = FontWeight.ExtraBold)) {
              append("Super")
            }
            withStyle(SpanStyle(color = TelebirrGold, fontWeight = FontWeight.ExtraBold)) {
              append("App")
            }
          },
        fontSize = 28.sp,
        letterSpacing = 0.3.sp,
      )
    }
  }
}
